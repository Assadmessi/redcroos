import '../models/models.dart';
import '../../core/constants/app_constants.dart';
import '../../core/utils/permission_service.dart';

// ═══════════════════════════════════════════════════════════════
// MOCK MEMBER DATA
// Real Company 1 & 3 rosters from org chart files.
// Company 2 & 4: roles only, no names (blank positions).
// Brigade Office: roles only, except Commander (m1) and Deputy (m2)
// which carry real data per user instruction.
//
// Member IDs (m1, m2, m3, m101...) match the existing
// auth_provider.dart mock credentials exactly — login keeps working.
// ═══════════════════════════════════════════════════════════════
class MockMembers {
  MockMembers._();

  static Member? findById(String id) {
    try {
      return all.firstWhere((m) => m.id == id);
    } catch (_) {
      return null;
    }
  }

  static List<Member> get all => [
    // ─────────────────────────────────────────────────────────
    // BRIGADE OFFICE
    // ─────────────────────────────────────────────────────────

    // m1 — Brigade Commander — ဒေါ်ခင်သန်းစိုး
    Member(
      id: 'm1',
      memberNo: 'RC-001',
      nameEn: 'Daw Khin Than Soe',
      nameMm: 'ဒေါ်ခင်သန်းစိုး',
      rank: MemberRank.brigadeCommander,
      unitType: UnitType.brigadeOffice,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(1984, 10, 21),
      currentRankDate: DateTime(2017, 1, 1),
      phone: '09 442 527 816',
      email: '',
      address: 'ရန်ကုန်တိုင်းဒေသကြီး',
      dateOfBirth: DateTime(1973, 8, 28),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.admin,
      gender: Gender.female,
      nrc: '၁၂/ဗတထ(နိုင်)၀၂၃၉၈၁',
      membershipNo: 'ရက-၈၃၂၇',
      isAdminRole: true,
      membershipType: MembershipType.official,
    ),

    // m2 — Deputy Brigade Commander — ဦးရန်ပိုင်
    Member(
      id: 'm2',
      memberNo: 'RC-002',
      nameEn: 'U Yan Paing',
      nameMm: 'ဦးရန်ပိုင်',
      rank: MemberRank.deputyBrigadeCommander,
      unitType: UnitType.brigadeOffice,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2000, 1, 1),
      currentRankDate: DateTime(2020, 1, 1),
      phone: '09 429 111 807',
      email: '',
      address: 'ရန်ကုန်တိုင်းဒေသကြီး',
      dateOfBirth: DateTime(1975, 1, 1),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.topBrass,
      gender: Gender.male,
      nrc: '၁၂/မတတ(နိုင်)၀၂၉၁၄၆',
      membershipNo: 'ရက-၉၂၂၂',
      membershipType: MembershipType.official,
    ),

    // m3 — Brigade Office Chief — role only, no name
    Member(
      id: 'm3',
      memberNo: 'RC-003',
      nameEn: '',
      nameMm: '',
      rank: MemberRank.companyCommander, // Brigade Office Chief uses Company Commander rank per Module 3 notes
      unitType: UnitType.brigadeOffice,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2020, 1, 1),
      dateOfBirth: DateTime(1980, 1, 1),
      phone: '',
      email: '',
      address: '',
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      isBrigadeOfficeChief: true,
      role: UserRole.seniorOfficer,
      gender: Gender.male,
    ),

    // m6 — Warrant Officer (Brigade Office) — role only
    Member(
      id: 'm6',
      memberNo: 'RC-006',
      nameEn: '',
      nameMm: '',
      rank: MemberRank.warrantOfficer,
      unitType: UnitType.brigadeOffice,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2020, 1, 1),
      dateOfBirth: DateTime(1980, 1, 1),
      phone: '',
      email: '',
      address: '',
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.officer,
      gender: Gender.male,
    ),

    // m7 — Sergeant Clerk (Brigade Office) — role only
    Member(
      id: 'm7',
      memberNo: 'RC-007',
      nameEn: '',
      nameMm: '',
      rank: MemberRank.sergeantClerk,
      unitType: UnitType.brigadeOffice,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2020, 1, 1),
      dateOfBirth: DateTime(1980, 1, 1),
      phone: '',
      email: '',
      address: '',
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.dutyOfficer,
      gender: Gender.male,
    ),

    // ─────────────────────────────────────────────────────────
    // COMPANY 1 — Full data from C1_Organization_Chart.xlsx
    // ─────────────────────────────────────────────────────────

    // m101 — Company 1 Commander — ဦးစိုးမင်း
    Member(
      id: 'm101',
      memberNo: 'RC-101',
      nameEn: 'U Soe Minn',
      nameMm: 'ဦးစိုးမင်း',
      rank: MemberRank.companyCommander,
      unitType: UnitType.company,
      companyNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(1984, 10, 21),
      currentRankDate: DateTime(2017, 7, 1),
      phone: '09 254 127 176',
      email: '',
      address: 'အမှတ် (၄၃၄) ကုန်သည်လမ်း၊ အမှတ် (၈) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(1973, 8, 28),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.seniorOfficer,
      gender: Gender.male,
      nrc: '၁၂/ဗတထ(နိုင်)၀၀၁၅၄၀',
      ygnId: '13017/00024',
      membershipNo: 'တဖ-ရက/ဗတထ/၃',
      membershipType: MembershipType.official,
    ),

    // m102 — Company 1 Deputy Commander — ဦးအောင်ဝေထွန်း
    Member(
      id: 'm102',
      memberNo: 'RC-102',
      nameEn: 'U Aung Wai Htun',
      nameMm: 'ဦးအောင်ဝေထွန်း',
      rank: MemberRank.deputyCompanyCommander,
      unitType: UnitType.company,
      companyNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(1993, 6, 12),
      currentRankDate: DateTime(2020, 1, 8),
      phone: '09 510 1069',
      email: '',
      address: 'အမှတ် (၄၆၃/၁၂) ကုန်သည်လမ်း၊ အမှတ် (၇) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(1982, 6, 1),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.officer,
      gender: Gender.male,
      nrc: '၁၂/ဗတထ(နိုင်)၀၃၄၅၁၈',
      ygnId: '13017/00061',
      membershipNo: 'တဖ-ရက/ဗတထ/၉',
      membershipType: MembershipType.official,
    ),

    // m103 — C1 Platoon 1 Leader — ဦးလှမြင့်ဦး (used as Module 3 sample "Platoon Leader C1/P1")
    Member(
      id: 'm103',
      memberNo: 'RC-103',
      nameEn: 'U Hla Myint Oo',
      nameMm: 'ဦးလှမြင့်ဦး',
      rank: MemberRank.platoonLeader,
      unitType: UnitType.platoon,
      companyNo: 1,
      platoonNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2020, 2, 20),
      currentRankDate: DateTime(2026, 1, 1),
      phone: '09 784 854 886',
      email: '',
      address: 'အမှတ် (၁၄၅) (၄၇) လမ်း၊ အမှတ် (၁၀) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(1998, 8, 5),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.officer,
      gender: Gender.male,
      nrc: '၁၂/ဗတထ(နိုင်)၀၄၂၆၂၄',
      ygnId: '13017/00030',
      membershipNo: 'တဖ-ရက/ဗတထ/၃၀',
      membershipType: MembershipType.official,
    ),

    // m104 — C1/P1/S1 Section Leader — vacant in org chart, kept as test login per Module 3
    Member(
      id: 'm104',
      memberNo: 'RC-104',
      nameEn: '',
      nameMm: '',
      rank: MemberRank.sectionLeader,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 1,
      sectionNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2020, 1, 1),
      dateOfBirth: DateTime(1990, 1, 1),
      phone: '',
      email: '',
      address: '',
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.dutyOfficer,
      gender: Gender.male,
    ),

    // m105 — C1/P1/S1 Private — ကိုအောင်နန္ဒ (used as Module 3 sample "Private C1/P1/S1")
    Member(
      id: 'm105',
      memberNo: 'RC-105',
      nameEn: 'Ko Aung Nanda',
      nameMm: 'ကိုအောင်နန္ဒ',
      rank: MemberRank.private,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 1,
      sectionNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2024, 7, 15),
      currentRankDate: DateTime(2024, 7, 15),
      phone: '09 964 578 724',
      email: '',
      address: 'အခန်း (၅/J) မလိခဆောင်၊ ရဲရိပ်သာရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2005, 10, 2),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
      nrc: '၁၂/မဂတ(နိုင်)၁၁၆၇၇၅',
      ygnId: '13017/02664',
      membershipNo: 'တဖ-ရက/ဗတထ/၆၂',
      membershipType: MembershipType.official,
    ),

    // m106 — C1 Sergeant Major (Office) — ကိုဝေဖြိုးပိုင်
    Member(
      id: 'm106',
      memberNo: 'RC-106',
      nameEn: 'Ko Wai Phyo Paing',
      nameMm: 'ကိုဝေဖြိုးပိုင်',
      rank: MemberRank.companySergeantMajor,
      unitType: UnitType.company,
      companyNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.ABP,
      joinDate: DateTime(2021, 8, 22),
      currentRankDate: DateTime(2024, 9, 1),
      phone: '09 683 396 936',
      email: '',
      address: 'အခန်း (၁)၊ (၆) ခန်းတွဲ၊ ရဲရိပ်သာရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2000, 1, 5),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.dutyOfficer,
      gender: Gender.male,
      nrc: '၇/လပတ(နိုင်)၁၇၁၅၅၇',
      ygnId: '13017/02254',
      membershipNo: 'တဖ-ရက/ဗတထ/၄၆',
      membershipType: MembershipType.official,
    ),

    // m107 — C1 Platoon 1 Sergeant — ကိုအောင်ဘုန်းခန့်
    Member(
      id: 'm107',
      memberNo: 'RC-107',
      nameEn: 'Ko Aung Bhone Khant',
      nameMm: 'ကိုအောင်ဘုန်းခန့်',
      rank: MemberRank.platoonSergeant,
      unitType: UnitType.platoon,
      companyNo: 1,
      platoonNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.AP,
      joinDate: DateTime(2024, 8, 27),
      currentRankDate: DateTime(2025, 1, 1),
      phone: '09 679 952 011',
      email: '',
      address: 'COD အပေါ်ဝင်း၊ စန္ဒကူးလမ်း၊ အမှတ် (၃) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2008, 1, 27),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.dutyOfficer,
      gender: Gender.male,
      nrc: '၁၂/ဗတထ(နိုင်)၀၅၀၂၄၈',
      ygnId: '13017/02485',
      membershipNo: 'တဖ-ရက/ဗတထ/၆၁',
      membershipType: MembershipType.official,
    ),

    // m108 — C1/P1/S2 Section Leader — ကိုဇော်လွင်ဝင်း
    Member(
      id: 'm108',
      memberNo: 'RC-108',
      nameEn: 'Ko Zaw Lwin Win',
      nameMm: 'ကိုဇော်လွင်ဝင်း',
      rank: MemberRank.sectionLeader,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 1,
      sectionNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(2020, 3, 26),
      currentRankDate: DateTime(2024, 9, 1),
      phone: '09 740 849 184',
      email: '',
      address: 'အမှတ် (၄၃၄) ကုန်သည်လမ်း၊ အမှတ် (၈) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2001, 6, 19),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.dutyOfficer,
      gender: Gender.male,
      nrc: '၁၄/အမန(နိုင်)၂၁၀၈၄၄',
      ygnId: '13017/01342',
      membershipNo: 'တဖ-ရက/ဗတထ/၆၄',
      membershipType: MembershipType.official,
    ),

    // m109 — C1/P1/S1 Deputy Section Leader — ကိုထက်မြတ်အောင်
    Member(
      id: 'm109',
      memberNo: 'RC-109',
      nameEn: 'Ko Htet Myat Aung',
      nameMm: 'ကိုထက်မြတ်အောင်',
      rank: MemberRank.deputySectionLeader,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 1,
      sectionNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(2024, 11, 21),
      currentRankDate: DateTime(2026, 1, 1),
      phone: '09 698 276 770',
      email: '',
      address: 'မီးပြဝင်း၊ အမှတ် (၁) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2009, 3, 8),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
      nrc: '၁၂/ဆကန(နိုင်)၀၀၂၉၉၄',
      ygnId: '13017/02661',
      membershipNo: 'တဖ-ရက/ဗတထ/၉၉',
      membershipType: MembershipType.official,
    ),

    // m110 — C1/P1/S1 Deputy Section Leader — ကိုစေပိုင်
    Member(
      id: 'm110',
      memberNo: 'RC-110',
      nameEn: 'Ko Say Paing',
      nameMm: 'ကိုစေပိုင်',
      rank: MemberRank.deputySectionLeader,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 1,
      sectionNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(2024, 11, 21),
      currentRankDate: DateTime(2026, 1, 1),
      phone: '09 458 590 534',
      email: '',
      address: 'COD အပေါ်ဝင်း၊ စန္ဒကူးလမ်း၊ အမှတ် (၃) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2010, 5, 25),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
      nrc: 'လျှောက်ထားဆဲ',
      ygnId: '13017/02692',
      membershipNo: 'သမ-၃/ဗတထ/ရက',
      membershipType: MembershipType.probationer,
    ),

    // m111 — C1/P1/S2 Deputy Section Leader — ကိုဇေပိုင်
    Member(
      id: 'm111',
      memberNo: 'RC-111',
      nameEn: 'Ko Zay Paing',
      nameMm: 'ကိုဇေပိုင်',
      rank: MemberRank.deputySectionLeader,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 1,
      sectionNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(2024, 11, 21),
      currentRankDate: DateTime(2026, 1, 1),
      phone: '09 677 450 369',
      email: '',
      address: 'COD အပေါ်ဝင်း၊ စန္ဒကူးလမ်း၊ အမှတ် (၃) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2010, 5, 25),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
      nrc: 'လျှောက်ထားဆဲ',
      ygnId: '13017/02691',
      membershipNo: 'သမ-၂/ဗတထ/ရက',
      membershipType: MembershipType.probationer,
    ),

    // m112 — C1/P1/S2 Deputy Section Leader — ကိုဝေဖြိုးအောင်
    Member(
      id: 'm112',
      memberNo: 'RC-112',
      nameEn: 'Ko Wai Phyo Aung',
      nameMm: 'ကိုဝေဖြိုးအောင်',
      rank: MemberRank.deputySectionLeader,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 1,
      sectionNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(2024, 11, 21),
      currentRankDate: DateTime(2026, 1, 1),
      phone: '09 683 896 019',
      email: '',
      address: 'COD အပေါ်ဝင်း၊ စန္ဒကူးလမ်း၊ အမှတ် (၃) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2010, 2, 23),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
      nrc: 'လျှောက်ထားဆဲ',
      ygnId: '13017/02687',
      membershipNo: 'သမ-၁/ဗတထ/ရက',
      membershipType: MembershipType.probationer,
    ),

    // m113-m115 — C1/P1/S1 Privates
    Member(
      id: 'm113',
      memberNo: 'RC-113',
      nameEn: 'Ko Myo Myat Yan Naing Min',
      nameMm: 'ကိုမျိုးမြတ်ရန်နိုင်မင်း',
      rank: MemberRank.private,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 1,
      sectionNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2025, 8, 11),
      currentRankDate: DateTime(2025, 8, 11),
      phone: '09 661 812 574',
      email: '',
      address: 'သမတကမ်းခြေ၊ ဒလမြို့နယ်',
      dateOfBirth: DateTime(2009, 2, 5),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
      nrc: 'လျှောက်ထားဆဲ',
      membershipNo: 'တဖ-ရက/ဗတထ/၁၂၃',
      membershipType: MembershipType.official,
    ),

    Member(
      id: 'm114',
      memberNo: 'RC-114',
      nameEn: 'Ko Kaung Htet Aung',
      nameMm: 'ကိုကောင်းထက်အောင်',
      rank: MemberRank.private,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 1,
      sectionNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(2025, 4, 27),
      currentRankDate: DateTime(2025, 4, 27),
      phone: '09 775 108 143',
      email: '',
      address: 'အမှတ် (၃၉) (၆၁) လမ်း၊ အမှတ် (၃) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2012, 2, 13),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
      nrc: 'လျှောက်ထားဆဲ',
      ygnId: '13017/02747',
      membershipNo: 'သမ-၁၅/ဗတထ/ရက',
      membershipType: MembershipType.probationer,
    ),

    // m115 — C1/P1/S2 Private
    Member(
      id: 'm115',
      memberNo: 'RC-115',
      nameEn: 'Ko Kyaw Lin Htut',
      nameMm: 'ကိုကျော်လင်းထွဋ်',
      rank: MemberRank.private,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 1,
      sectionNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2025, 1, 4),
      currentRankDate: DateTime(2025, 1, 4),
      phone: '09 758 264 726',
      email: '',
      address: 'COD အပေါ်ဝင်း၊ စန္ဒကူးလမ်း၊ အမှတ် (၃) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2010, 6, 11),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
      nrc: 'လျှောက်ထားဆဲ',
      ygnId: '13017/02694',
      membershipNo: 'သမ-၁၃/ဗတထ/ရက',
      membershipType: MembershipType.probationer,
    ),

    Member(
      id: 'm116',
      memberNo: 'RC-116',
      nameEn: 'Ko Min Than Zin',
      nameMm: 'ကိုမင်းသံစဉ်',
      rank: MemberRank.private,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 1,
      sectionNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2025, 1, 1),
      currentRankDate: DateTime(2025, 1, 1),
      phone: '09956740007',
      email: '',
      address: 'တိုက် (ဒီ) အခန်း (၂၀၁) မင်္ဂလာဥယျာဉ်အိမ်ရာ၊ တာမွေမြို့နယ်',
      dateOfBirth: DateTime(2010, 7, 15),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
      nrc: '၁၂/ဥကတ(နိုင်)၂၁၅၂၈၆',
      ygnId: '13017/02728',
      membershipNo: 'သမ-၁၄/ဗတထ/ရက',
      membershipType: MembershipType.probationer,
    ),

    Member(
      id: 'm117',
      memberNo: 'RC-117',
      nameEn: 'Ko Zwell Khant Ko Ko',
      nameMm: 'ကိုဇွဲခန့်ကိုကို',
      rank: MemberRank.private,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 1,
      sectionNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.AP,
      joinDate: DateTime(2020, 8, 19),
      currentRankDate: DateTime(2026, 1, 1),
      phone: '09 777 213 326',
      email: '',
      address: 'အနော်ရထာလမ်း၊ အံ့ကြီးရပ်ကွက်၊ ဒလမြို့နယ်',
      dateOfBirth: DateTime(1999, 11, 2),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
      nrc: '၁၂/ဒလန(နိုင်)၂၇၀၃၁၅',
      ygnId: '13017/00066',
      membershipNo: 'တဖ-ရက/ဗတထ/၄၅',
      membershipType: MembershipType.official,
    ),

    // m118 — Company 1 Platoon 2 Leader — ဦးပြည့်ဖြိုးအောင်
    Member(
      id: 'm118',
      memberNo: 'RC-118',
      nameEn: 'U Pyae Phyo Aung',
      nameMm: 'ဦးပြည့်ဖြိုးအောင်',
      rank: MemberRank.platoonLeader,
      unitType: UnitType.platoon,
      companyNo: 1,
      platoonNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(2020, 3, 31),
      currentRankDate: DateTime(2024, 9, 1),
      phone: '09 423 407 064',
      email: '',
      address: 'အမှတ် (၃၅) ရေတပ်စက်မှုလက်မှုတပ်၊ GE ဝင်း၊ သန်လျက်စွန်း၊ အမှတ် (၁) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2000, 1, 20),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.officer,
      gender: Gender.male,
      nrc: '၁၂/သကတ(နိုင်)၂၁၀၃၈၂',
      ygnId: '13017/00070',
      membershipNo: 'တဖ-ရက/ဗတထ/၄၄',
      membershipType: MembershipType.official,
    ),

    // m119 — Company 1 Platoon 2 Sergeant — ကိုနိုင်စစ်မှူး
    Member(
      id: 'm119',
      memberNo: 'RC-119',
      nameEn: 'Ko Naing Sitt Hmu',
      nameMm: 'ကိုနိုင်စစ်မှူး',
      rank: MemberRank.platoonSergeant,
      unitType: UnitType.platoon,
      companyNo: 1,
      platoonNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2021, 2, 17),
      currentRankDate: DateTime(2025, 4, 1),
      phone: '09 404 484 173',
      email: '',
      address: 'အမှတ် (၁၄၇) ဗိုလ်ချုပ်အောင်ဆန်းလမ်း၊ အမှတ် (၁၀) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2004, 10, 2),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.dutyOfficer,
      gender: Gender.male,
      nrc: '၁၂/သလန(နိုင်)၁၆၂၉၀၃',
      ygnId: '13017/01296',
      membershipNo: 'တဖ-ရက/ဗတထ/၆၅',
      membershipType: MembershipType.official,
    ),

    // m120 — C1/P2/S1 Section Leader — ကိုပိုင်မျိုးသူ
    Member(
      id: 'm120',
      memberNo: 'RC-120',
      nameEn: 'Ko Paing Myo Thu',
      nameMm: 'ကိုပိုင်မျိုးသူ',
      rank: MemberRank.sectionLeader,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 2,
      sectionNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2024, 6, 30),
      currentRankDate: DateTime(2025, 1, 1),
      phone: '09 976 493 268',
      email: '',
      address: 'အမှတ် (၂၈၆) ကုန်သည်လမ်း၊ အမှတ် (၄) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2007, 9, 20),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.dutyOfficer,
      gender: Gender.male,
      nrc: '၁၂/ဗတထ(နိုင်)၀၄၉၄၁၉',
      ygnId: '13017/01318',
      membershipNo: 'တဖ-ရက/ဗတထ/၅၉',
      membershipType: MembershipType.official,
    ),

    // m121 — C1/P2/S2 Section Leader — ကိုဇော်ဌေးအောင်
    Member(
      id: 'm121',
      memberNo: 'RC-121',
      nameEn: 'Ko Zaw Htay Aung',
      nameMm: 'ကိုဇော်ဌေးအောင်',
      rank: MemberRank.sectionLeader,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 2,
      sectionNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2020, 8, 19),
      currentRankDate: DateTime(2025, 4, 1),
      phone: '09 751 272 290',
      email: '',
      address: 'ပညာရာမိကမဟာ(A)တိုက် ဘုန်းကြီးကျောင်း၊ သိမ်ဖြူလမ်း၊ အမှတ် (၁၀) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2000, 2, 15),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.dutyOfficer,
      gender: Gender.male,
      nrc: '၈/ပဖန(နိုင်)၁၇၇၂၉၉',
      ygnId: '13017/00072',
      membershipNo: 'တဖ-ရက/ဗတထ/၄၃',
      membershipType: MembershipType.official,
    ),

    // m122 — C1/P2/S1 Deputy Section Leader — ကိုစိုင်းသူရဇော်ဘွမ်ဦး
    Member(
      id: 'm122',
      memberNo: 'RC-122',
      nameEn: 'Ko Sai Thura Zaw Bwan Oo',
      nameMm: 'ကိုစိုင်းသူရဇော်ဘွမ်ဦး',
      rank: MemberRank.deputySectionLeader,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 2,
      sectionNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.AP,
      joinDate: DateTime(2021, 11, 17),
      currentRankDate: DateTime(2024, 9, 1),
      phone: '09 893 568 291',
      email: '',
      address: 'အမှတ် (၃၉) ဇီဇဝါလမ်း၊ ရေကျော်၊ ပုဇွန်တောင်မြို့နယ်',
      dateOfBirth: DateTime(2005, 8, 12),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
      nrc: '၁၂/ပဇတ(နိုင်)၀၄၂၇၆၇',
      ygnId: '13017/02727',
      membershipNo: 'တဖ-ရက/ဗတထ/၅၈',
      membershipType: MembershipType.official,
    ),

    // m123 — C1/P2/S1 Deputy Section Leader — vacant
    Member(
      id: 'm123',
      memberNo: 'RC-123',
      nameEn: '',
      nameMm: '',
      rank: MemberRank.deputySectionLeader,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 2,
      sectionNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2020, 1, 1),
      dateOfBirth: DateTime(1990, 1, 1),
      phone: '',
      email: '',
      address: '',
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
    ),

    // m124 — C1/P2/S2 Deputy Section Leader — ကိုဝင်းမြတ်အောင်
    Member(
      id: 'm124',
      memberNo: 'RC-124',
      nameEn: 'Ko Win Myat Aung',
      nameMm: 'ကိုဝင်းမြတ်အောင်',
      rank: MemberRank.deputySectionLeader,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 2,
      sectionNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(2025, 9, 6),
      currentRankDate: DateTime(2025, 9, 6),
      phone: '09 660 250 320',
      email: '',
      address: 'G-11 ရေနံလိုင်း၊ သန်လျက်စွန်းလမ်း၊ အမှတ် (၁) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2007, 1, 20),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
      nrc: '၁၂/ဗတထ(နိုင်)၀၄၅၈၂၆',
      membershipNo: 'တဖ-ရက/ဗတထ/၁၂၁',
      membershipType: MembershipType.official,
    ),

    // m125 — C1/P2/S2 Deputy Section Leader — ကိုဇေယျာဝင်းထွဋ်
    Member(
      id: 'm125',
      memberNo: 'RC-125',
      nameEn: 'Ko Zayar Win Htut',
      nameMm: 'ကိုဇေယျာဝင်းထွဋ်',
      rank: MemberRank.deputySectionLeader,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 2,
      sectionNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(2025, 4, 20),
      currentRankDate: DateTime(2025, 4, 20),
      phone: '09 776 219 946',
      email: '',
      address: 'ထော်အောက်ကျေးရွာ၊ ဒလမြို့နယ်',
      dateOfBirth: DateTime(1998, 5, 26),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
      nrc: '၁၂/ဒလန(နိုင်)၀၆၂၆၄၉',
      ygnId: '13017/02694',
      membershipNo: 'တဖ-ရက/ဗတထ/၁၁၆',
      membershipType: MembershipType.official,
    ),

    // m126-m128 — C1/P2/S1 Privates
    Member(
      id: 'm126',
      memberNo: 'RC-126',
      nameEn: 'Ko Htet Win Aung',
      nameMm: 'ကိုထက်ဝင်းအောင်',
      rank: MemberRank.private,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 2,
      sectionNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2024, 12, 7),
      currentRankDate: DateTime(2024, 12, 7),
      phone: '09 694 076 944',
      email: '',
      address: 'အခန်း (၁၉) သဇင်လိုင်း၊ ဧရခ၊ အမှတ် (၁) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2008, 4, 5),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
      nrc: '၁၂/တမန(နိုင်)၁၃၆၄၁၈',
      ygnId: '13017/02666',
      membershipNo: 'တဖ-ရက/ဗတထ/၁၀၅',
      membershipType: MembershipType.official,
    ),

    Member(
      id: 'm127',
      memberNo: 'RC-127',
      nameEn: 'Ko Htoo Ent Shein',
      nameMm: 'ကိုထူးအံ့ရှိန်',
      rank: MemberRank.private,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 2,
      sectionNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(2025, 9, 6),
      currentRankDate: DateTime(2025, 9, 6),
      phone: '09 671 694 693',
      email: '',
      address: 'G-11 ရေနံလိုင်း၊ သန်လျက်စွန်းလမ်း၊ အမှတ် (၁) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2001, 4, 3),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
      nrc: '၁၂/ဗတထ(နိုင်)၀၄၃၅၃၉',
      membershipNo: '',
      membershipType: MembershipType.official,
    ),

    // m128 — C1/P2/S1 Private — vacant
    Member(
      id: 'm128',
      memberNo: 'RC-128',
      nameEn: '',
      nameMm: '',
      rank: MemberRank.private,
      unitType: UnitType.section,
      companyNo: 1,
      platoonNo: 2,
      sectionNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2020, 1, 1),
      dateOfBirth: DateTime(1990, 1, 1),
      phone: '',
      email: '',
      address: '',
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.male,
    ),

    // m129-m131 — C1/P2/S2 Privates — all vacant
    Member(
      id: 'm129', memberNo: 'RC-129', nameEn: '', nameMm: '',
      rank: MemberRank.private, unitType: UnitType.section,
      companyNo: 1, platoonNo: 2, sectionNo: 2,
      status: MemberStatus.active, bloodType: BloodType.OP,
      joinDate: DateTime(2020, 1, 1), dateOfBirth: DateTime(1990, 1, 1),
      phone: '', email: '', address: '', emergencyContact: '', emergencyPhone: '',
      skillIds: const [], role: UserRole.member, gender: Gender.male,
    ),
    Member(
      id: 'm130', memberNo: 'RC-130', nameEn: '', nameMm: '',
      rank: MemberRank.private, unitType: UnitType.section,
      companyNo: 1, platoonNo: 2, sectionNo: 2,
      status: MemberStatus.active, bloodType: BloodType.OP,
      joinDate: DateTime(2020, 1, 1), dateOfBirth: DateTime(1990, 1, 1),
      phone: '', email: '', address: '', emergencyContact: '', emergencyPhone: '',
      skillIds: const [], role: UserRole.member, gender: Gender.male,
    ),
    Member(
      id: 'm131', memberNo: 'RC-131', nameEn: '', nameMm: '',
      rank: MemberRank.private, unitType: UnitType.section,
      companyNo: 1, platoonNo: 2, sectionNo: 2,
      status: MemberStatus.active, bloodType: BloodType.OP,
      joinDate: DateTime(2020, 1, 1), dateOfBirth: DateTime(1990, 1, 1),
      phone: '', email: '', address: '', emergencyContact: '', emergencyPhone: '',
      skillIds: const [], role: UserRole.member, gender: Gender.male,
    ),

    // ─────────────────────────────────────────────────────────
    // COMPANY 2 — Intentionally empty for now.
    // No mock data entries. Structure, permissions, and rank/unit
    // logic (UnitType.company/platoon, companyNo: 2, the Company 2
    // filter option, permission scope rules, etc.) all remain fully
    // intact elsewhere in the app — only the placeholder data here
    // was removed. To re-add Company 2 later, copy the Company 1 or
    // Company 3 block's structure (Commander → Deputy → Sgt Major →
    // Platoons → Sections → Privates) with companyNo: 2.
    // ─────────────────────────────────────────────────────────

    // ─────────────────────────────────────────────────────────
    // COMPANY 3 — Full data from C3_Organization_Chart.xlsx
    // ─────────────────────────────────────────────────────────

    // m301 — Company 3 Commander — VACANT (unfilled in org chart)
    Member(
      id: 'm301', memberNo: 'RC-301', nameEn: '', nameMm: '',
      rank: MemberRank.companyCommander, unitType: UnitType.company,
      companyNo: 3, status: MemberStatus.active, bloodType: BloodType.OP,
      joinDate: DateTime(2020,1,1), dateOfBirth: DateTime(1980,1,1),
      phone: '', email: '', address: '', emergencyContact: '', emergencyPhone: '',
      skillIds: const [], role: UserRole.seniorOfficer, gender: Gender.female,
    ),

    // m302 — Company 3 Deputy Commander — ဒေါ်လင်းလက်တာရာ
    Member(
      id: 'm302',
      memberNo: 'RC-302',
      nameEn: 'Daw Lin Let Tara Ya',
      nameMm: 'ဒေါ်လင်းလက်တာရာ',
      rank: MemberRank.deputyCompanyCommander,
      unitType: UnitType.company,
      companyNo: 3,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2020, 5, 15),
      currentRankDate: DateTime(2024, 9, 1),
      phone: '09 422 618 394',
      email: '',
      address: 'အမှတ် (ဘီ/၃) ကြာဖြူလမ်း၊ အမှတ် (၁) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2002, 11, 13),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.officer,
      gender: Gender.female,
      nrc: 'လျှောက်ထားဆဲ',
      ygnId: '13017/00065',
      membershipNo: 'တဖ-ရက/ဗတထ/၂၇',
      membershipType: MembershipType.official,
    ),

    // m303 — Company 3 Sergeant Major (Office) — မအင်ကြင်းအေး
    Member(
      id: 'm303',
      memberNo: 'RC-303',
      nameEn: 'Ma Ain Kying Aye',
      nameMm: 'မအင်ကြင်းအေး',
      rank: MemberRank.companySergeantMajor,
      unitType: UnitType.company,
      companyNo: 3,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2020, 1, 1),
      currentRankDate: DateTime(2026, 1, 1),
      phone: '09 968 130 953',
      email: '',
      address: '2H မလိခဆောင်၊ ဗိုလ်တထောင်ဘုရားဝန်ထမ်းလိုင်း၊ ရဲရိပ်သာရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2005, 3, 27),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.dutyOfficer,
      gender: Gender.female,
      nrc: '၁၂/ဆကန(နိုင်)၀၀၂၉၁၉',
      ygnId: '13017/01315',
      membershipNo: 'တဖ-ရက/ဗတထ/၁၀၇',
      membershipType: MembershipType.official,
    ),

    // m304 — Company 3 Platoon 1 Leader — ဒေါ်သန်းသန်းစံ
    Member(
      id: 'm304',
      memberNo: 'RC-304',
      nameEn: 'Daw Than Than San',
      nameMm: 'ဒေါ်သန်းသန်းစံ',
      rank: MemberRank.platoonLeader,
      unitType: UnitType.platoon,
      companyNo: 3,
      platoonNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2014, 6, 30),
      currentRankDate: DateTime(2020, 1, 1),
      phone: '09 781 988 301',
      email: '',
      address: 'တိုက် (D)၊ အခန်း (၈)၊ ရေနံလိုင်း၊ သန်လျှက်စွန်းလမ်း၊ အမှတ် (၁) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2002, 5, 17),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.officer,
      gender: Gender.female,
      nrc: '၁၂/ဗတထ(နိုင်)၀၄၆၂၀၇',
      ygnId: '13017/01872',
      membershipNo: 'တဖ-ရက/ဗတထ/၁၇',
      membershipType: MembershipType.official,
    ),

    // m305 — Company 3 Platoon 1 Sergeant — မကေဇင်ဟန်
    Member(
      id: 'm305',
      memberNo: 'RC-305',
      nameEn: 'Ma Kay Zin Han',
      nameMm: 'မကေဇင်ဟန်',
      rank: MemberRank.platoonSergeant,
      unitType: UnitType.platoon,
      companyNo: 3,
      platoonNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.AP,
      joinDate: DateTime(2022, 1, 3),
      currentRankDate: DateTime(2024, 9, 1),
      phone: '09 424 891 200',
      email: '',
      address: 'F-12 ရေနံမိသားစုလိုင်း၊ သန်လျက်စွန်းလမ်း၊ အမှတ် (၁) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2009, 5, 28),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.dutyOfficer,
      gender: Gender.female,
      nrc: '၁၂/ဗတထ(နိုင်)၀၄၇၉၁၃',
      ygnId: '13017/02259',
      membershipNo: 'တဖ-ရက/ဗတထ/၅၀',
      membershipType: MembershipType.official,
    ),

    // m306 — C3/P1/S1 Section Leader — မယုယဖြူ
    Member(
      id: 'm306',
      memberNo: 'RC-306',
      nameEn: 'Ma Yu Yu Phyu',
      nameMm: 'မယုယဖြူ',
      rank: MemberRank.sectionLeader,
      unitType: UnitType.section,
      companyNo: 3,
      platoonNo: 1,
      sectionNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(2024, 6, 29),
      currentRankDate: DateTime(2025, 1, 1),
      phone: '09 769 635 257',
      email: '',
      address: 'အမှတ် (၂) ဇင်ယော်လမ်း၊ အမှတ် (၂) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2009, 10, 21),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.dutyOfficer,
      gender: Gender.female,
      nrc: '၁၂/ဗတထ(နိုင်)၀၄၈၀၉၅',
      ygnId: '13017/02671',
      membershipNo: 'သမ-၆/ဗတထ/ရက',
      membershipType: MembershipType.probationer,
    ),

    // m307 — C3/P1/S2 Section Leader — မအိမ့်လဝန်း
    Member(
      id: 'm307',
      memberNo: 'RC-307',
      nameEn: 'Ma Eaint La Wun',
      nameMm: 'မအိမ့်လဝန်း',
      rank: MemberRank.sectionLeader,
      unitType: UnitType.section,
      companyNo: 3,
      platoonNo: 1,
      sectionNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.AP,
      joinDate: DateTime(2023, 11, 30),
      currentRankDate: DateTime(2025, 1, 1),
      phone: '09 755 325 414',
      email: '',
      address: 'အခန်း (၄/D) တိုက် (၄၀) ရဲရိပ်သာရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2009, 8, 8),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.dutyOfficer,
      gender: Gender.female,
      nrc: '၁၂/ဒဂတ(နိုင်)၁၃၄၉၃၅',
      ygnId: '13017/02657',
      membershipNo: 'သမ-၁၀/ဗတထ/ရက',
      membershipType: MembershipType.probationer,
    ),

    // m308 — C3/P1/S1 Deputy Section Leader — မယုနန္ဒာလင်း
    Member(
      id: 'm308',
      memberNo: 'RC-308',
      nameEn: 'Ma Yu Nanda Lin',
      nameMm: 'မယုနန္ဒာလင်း',
      rank: MemberRank.deputySectionLeader,
      unitType: UnitType.section,
      companyNo: 3,
      platoonNo: 1,
      sectionNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(2024, 8, 27),
      currentRankDate: DateTime(2025, 1, 1),
      phone: '09 693 134 204',
      email: '',
      address: 'စည်ပင်ဝင်း၊ အမှတ် (၁) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2010, 7, 20),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.female,
      nrc: '၁၂/ဗတထ(နိုင်)၀၄၉၉၈၁',
      ygnId: '13017/02658',
      membershipNo: 'သမ-၇/ဗတထ/ရက',
      membershipType: MembershipType.probationer,
    ),

    // m309 — C3/P1/S1 Deputy Section Leader — မအိသဇင်နွယ်
    Member(
      id: 'm309',
      memberNo: 'RC-309',
      nameEn: 'Ma Eaint Thi Zin Nway',
      nameMm: 'မအိသဇင်နွယ်',
      rank: MemberRank.deputySectionLeader,
      unitType: UnitType.section,
      companyNo: 3,
      platoonNo: 1,
      sectionNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(2004, 6, 6),
      currentRankDate: DateTime(2026, 1, 1),
      phone: '09 667 491 099',
      email: '',
      address: 'လင်းစဒေါင်း၊ အမှတ် (၂) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2004, 6, 6),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.female,
      nrc: '၁၄/ဖပန(နိုင်)၂၆၆၃၂၄',
      membershipNo: 'တဖ-ရက/ဗတထ/၁၁၉',
      membershipType: MembershipType.official,
    ),

    // m310 — C3/P1/S2 Deputy Section Leader — မအိမ့်ချမ်းမြေ့မေ
    Member(
      id: 'm310',
      memberNo: 'RC-310',
      nameEn: 'Ma Eaint Chan Myae May',
      nameMm: 'မအိမ့်ချမ်းမြေ့မေ',
      rank: MemberRank.deputySectionLeader,
      unitType: UnitType.section,
      companyNo: 3,
      platoonNo: 1,
      sectionNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2024, 8, 25),
      currentRankDate: DateTime(2025, 1, 1),
      phone: '09 688 729 789',
      email: '',
      address: 'လိုင်း (၁) အခန်း (၂) ရေတပ်ဝင်း၊ သန်လျက်စွန်းလမ်း၊ အမှတ် (၁) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2010, 1, 13),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.female,
      nrc: 'လျှောက်ထားဆဲ',
      ygnId: '13017/02659',
      membershipNo: 'သမ-၈/ဗတထ/ရက',
      membershipType: MembershipType.probationer,
    ),

    // m311 — C3/P1/S2 Deputy Section Leader — မချိုသက်ခိုင်
    Member(
      id: 'm311',
      memberNo: 'RC-311',
      nameEn: 'Ma Cho Thet Khaing',
      nameMm: 'မချိုသက်ခိုင်',
      rank: MemberRank.deputySectionLeader,
      unitType: UnitType.section,
      companyNo: 3,
      platoonNo: 1,
      sectionNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2018, 3, 18),
      currentRankDate: DateTime(2026, 1, 1),
      phone: '09 782 378 485',
      email: '',
      address: 'အမှတ် (၉၄) မြောင်းကြီးလမ်း၊ အမှတ် (၉) ရပ်ကွက်၊ ပုဇွန်တောင်မြို့နယ်',
      dateOfBirth: DateTime(2006, 7, 24),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.member,
      gender: Gender.female,
      nrc: '၁၂/ပဇတ(နိုင်)၀၄၀၃၄၃',
      ygnId: '13016/00792',
      membershipNo: 'တဖ-ရက/ဗတထ/၁၂၀',
      membershipType: MembershipType.official,
    ),

    // m312-m314 — C3/P1/S1 Privates
    Member(
      id: 'm312', memberNo: 'RC-312',
      nameEn: 'Ma Hein Thet Su San', nameMm: 'မဟိန်းထက်စုစံ',
      rank: MemberRank.private, unitType: UnitType.section,
      companyNo: 3, platoonNo: 1, sectionNo: 1,
      status: MemberStatus.active, bloodType: BloodType.AP,
      joinDate: DateTime(2024,12,25), currentRankDate: DateTime(2024,12,25),
      phone: '09 769 968 721', email: '',
      address: 'အမှတ် (၆) အခန်း (၅) လင်းစတောင်းဈေးလမ်း၊ အမှတ် (၂) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2012,2,20), emergencyContact: '', emergencyPhone: '',
      skillIds: const [], role: UserRole.member, gender: Gender.female,
      nrc: '၁၂/ဗတထ(နိုင်)၀၄၉၃၀၆', ygnId: '13017/02689',
      membershipNo: 'သမ-၁၁/ဗတထ/ရက', membershipType: MembershipType.probationer,
    ),
    Member(
      id: 'm313', memberNo: 'RC-313',
      nameEn: 'Ma Mya Kay Khaing Aye', nameMm: 'မမြကေခိုင်အေး',
      rank: MemberRank.private, unitType: UnitType.section,
      companyNo: 3, platoonNo: 1, sectionNo: 1,
      status: MemberStatus.active, bloodType: BloodType.OP,
      joinDate: DateTime(2024,10,18), currentRankDate: DateTime(2024,10,18),
      phone: '09 650 897 934', email: '',
      address: 'အခန်း (၂၃) (၄၈) ခန်းတွဲလိုင်း၊ ရဲရိပ်သာရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2007,3,1), emergencyContact: '', emergencyPhone: '',
      skillIds: const [], role: UserRole.member, gender: Gender.female,
      nrc: '၁၂/ဆကန(နိုင်)၀၀၂၉၁၁', ygnId: '13017/02662',
      membershipNo: 'တဖ-ရက/ဗတထ/၈၂', membershipType: MembershipType.official,
    ),
    Member(
      id: 'm314', memberNo: 'RC-314',
      nameEn: 'Daw Wut Ye Zin', nameMm: 'ဒေါ်ဝတ်ရည်ဇင်',
      rank: MemberRank.private, unitType: UnitType.section,
      companyNo: 3, platoonNo: 1, sectionNo: 1,
      status: MemberStatus.active, bloodType: BloodType.BP,
      joinDate: DateTime(2017,6,1), currentRankDate: DateTime(2026,1,1),
      phone: '09 795 369 134', email: '',
      address: 'အမှတ် (၂၄၂) ဇမ္ဗူသီရိ (၈) လမ်း၊ အမှတ် (၆/အနောက်) ရပ်ကွက်၊ သာကေတမြို့နယ်',
      dateOfBirth: DateTime(1993,9,1), emergencyContact: '', emergencyPhone: '',
      skillIds: const [], role: UserRole.member, gender: Gender.female,
      nrc: '၁၂/သကတ(နိုင်)၁၈၃၁၁၅', ygnId: '13017/00071',
      membershipNo: 'တဖ-ရက/ဗတထ/၂၁', membershipType: MembershipType.official,
    ),

    // m315 — C3/P1/S2 Private — မနန်းမေ
    Member(
      id: 'm315', memberNo: 'RC-315',
      nameEn: 'Ma Nan May', nameMm: 'မနန်းမေ',
      rank: MemberRank.private, unitType: UnitType.section,
      companyNo: 3, platoonNo: 1, sectionNo: 2,
      status: MemberStatus.active, bloodType: BloodType.AP,
      joinDate: DateTime(2022,1,3), currentRankDate: DateTime(2026,1,1),
      phone: '09 675 621 747', email: '',
      address: 'F-6 ရေနံမိသားစုလိုင်း၊ သန်လျက်စွန်းလမ်း၊ အမှတ် (၁) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2007,12,22), emergencyContact: '', emergencyPhone: '',
      skillIds: const [], role: UserRole.member, gender: Gender.female,
      nrc: 'လျှောက်ထားဆဲ', ygnId: '13017/02486',
      membershipNo: 'တဖ-ရက/ဗတထ/၄၉', membershipType: MembershipType.official,
    ),

    // m316-m317 — C3/P1/S2 Privates — vacant
    Member(id: 'm316', memberNo: 'RC-316', nameEn: '', nameMm: '', rank: MemberRank.private, unitType: UnitType.section, companyNo: 3, platoonNo: 1, sectionNo: 2, status: MemberStatus.active, bloodType: BloodType.OP, joinDate: DateTime(2020,1,1), dateOfBirth: DateTime(1990,1,1), phone: '', email: '', address: '', emergencyContact: '', emergencyPhone: '', skillIds: const [], role: UserRole.member, gender: Gender.female),
    Member(id: 'm317', memberNo: 'RC-317', nameEn: '', nameMm: '', rank: MemberRank.private, unitType: UnitType.section, companyNo: 3, platoonNo: 1, sectionNo: 2, status: MemberStatus.active, bloodType: BloodType.OP, joinDate: DateTime(2020,1,1), dateOfBirth: DateTime(1990,1,1), phone: '', email: '', address: '', emergencyContact: '', emergencyPhone: '', skillIds: const [], role: UserRole.member, gender: Gender.female),

    // m318 — Company 3 Platoon 2 Leader — ဒေါ်နွေးအိကဗျာဖူး
    Member(
      id: 'm318',
      memberNo: 'RC-318',
      nameEn: 'Daw Nway Eaint Kabya Phu',
      nameMm: 'ဒေါ်နွေးအိကဗျာဖူး',
      rank: MemberRank.platoonLeader,
      unitType: UnitType.platoon,
      companyNo: 3,
      platoonNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.OP,
      joinDate: DateTime(2017, 12, 27),
      currentRankDate: DateTime(2024, 9, 1),
      phone: '09 965 586 110',
      email: '',
      address: 'အမှတ် (ဘီ/၃) ကြာဖြူလမ်း၊ အမှတ် (၁) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2005, 2, 12),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.officer,
      gender: Gender.female,
      nrc: 'လျှောက်ထားဆဲ',
      ygnId: '13017/00068',
      membershipNo: 'တဖ-ရက/ဗတထ/၄၂',
      membershipType: MembershipType.official,
    ),

    // m319 — Company 3 Platoon 2 Sergeant — မပန်းအိဇင်
    Member(
      id: 'm319',
      memberNo: 'RC-319',
      nameEn: 'Ma Pan Eaint Zin',
      nameMm: 'မပန်းအိဇင်',
      rank: MemberRank.platoonSergeant,
      unitType: UnitType.platoon,
      companyNo: 3,
      platoonNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(2021, 11, 26),
      currentRankDate: DateTime(2026, 1, 1),
      phone: '09 781 566 983',
      email: '',
      address: 'လိုင်း (၃) အခန်း (၃၁) လိုင်းသစ်၊ မီးရထားဝင်း၊ အမှတ် (၆) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2007, 7, 5),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.dutyOfficer,
      gender: Gender.female,
      nrc: '၉/ပဗသ(နိုင်)၀၃၁၂၀၀',
      ygnId: '13017/02487',
      membershipNo: 'တဖ-ရက/ဗတထ/၆၃',
      membershipType: MembershipType.official,
    ),

    // m320 — C3/P2/S1 Section Leader — မဆုဝေနှင်း
    Member(
      id: 'm320',
      memberNo: 'RC-320',
      nameEn: 'Ma Su Wai Hnin',
      nameMm: 'မဆုဝေနှင်း',
      rank: MemberRank.sectionLeader,
      unitType: UnitType.section,
      companyNo: 3,
      platoonNo: 2,
      sectionNo: 1,
      status: MemberStatus.active,
      bloodType: BloodType.AP,
      joinDate: DateTime(2021, 6, 1),
      currentRankDate: DateTime(2026, 1, 1),
      phone: '09 970 278 205',
      email: '',
      address: 'အမှတ် (၄၈) ဗိုလ်တေဇ (၁) လမ်း၊ တပင်ရွှေထီးရပ်ကွက်၊ ဒလမြို့နယ်',
      dateOfBirth: DateTime(1998, 9, 18),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.dutyOfficer,
      gender: Gender.female,
      nrc: '၁၂/ဒလန(နိုင်)၀၈၆၄၁၃',
      ygnId: '13017/02735',
      membershipNo: 'တဖ-ရက/ဗတထ/၁၁၅',
      membershipType: MembershipType.official,
    ),

    // m321 — C3/P2/S2 Section Leader — မအေးပြည့်သဇင်
    Member(
      id: 'm321',
      memberNo: 'RC-321',
      nameEn: 'Ma Aye Pyint Thar Zin',
      nameMm: 'မအေးပြည့်သဇင်',
      rank: MemberRank.sectionLeader,
      unitType: UnitType.section,
      companyNo: 3,
      platoonNo: 2,
      sectionNo: 2,
      status: MemberStatus.active,
      bloodType: BloodType.BP,
      joinDate: DateTime(2021, 1, 24),
      currentRankDate: DateTime(2025, 1, 1),
      phone: '09 421 064 678',
      email: '',
      address: 'လိုင်း (၁) အခန်း (၇) ဗိုလ်တထောင်ဘုရားလိုင်း၊ ရဲရိပ်သာရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2008, 8, 24),
      emergencyContact: '',
      emergencyPhone: '',
      skillIds: const [],
      role: UserRole.dutyOfficer,
      gender: Gender.female,
      nrc: 'လျှောက်ထားဆဲ',
      ygnId: '13017/01455',
      membershipNo: 'တဖ-ရက/ဗတထ/၇၃',
      membershipType: MembershipType.official,
    ),

    // m322-m323 — C3/P2/S1 Deputy Section Leaders
    Member(
      id: 'm322', memberNo: 'RC-322',
      nameEn: 'Ma Pwint Yati Aung', nameMm: 'မပွင့်ရတီအောင်',
      rank: MemberRank.deputySectionLeader, unitType: UnitType.section,
      companyNo: 3, platoonNo: 2, sectionNo: 1,
      status: MemberStatus.active, bloodType: BloodType.OP,
      joinDate: DateTime(2022,4,1), currentRankDate: DateTime(2024,9,1),
      phone: '09 403 547 287', email: '',
      address: 'အမှတ် (၃၉) ဇီဇဝါလမ်း၊ ရေကျော်၊ ပုဇွန်တောင်မြို့နယ်',
      dateOfBirth: DateTime(2005,2,3), emergencyContact: '', emergencyPhone: '',
      skillIds: const [], role: UserRole.member, gender: Gender.female,
      nrc: '၁၂/ပဇတ(နိုင်)၀၃၈၇၉၆', ygnId: '13017/01467',
      membershipNo: 'တဖ-ရက/ဗတထ/၅၆', membershipType: MembershipType.official,
    ),
    Member(
      id: 'm323', memberNo: 'RC-323',
      nameEn: 'Ma Kway Sin Paing Soe', nameMm: 'မကြယ်စင်ပိုင်စိုး',
      rank: MemberRank.deputySectionLeader, unitType: UnitType.section,
      companyNo: 3, platoonNo: 2, sectionNo: 1,
      status: MemberStatus.active, bloodType: BloodType.OP,
      joinDate: DateTime(2017,12,27), currentRankDate: DateTime(2026,1,1),
      phone: '09 422 618 394', email: '',
      address: 'အမှတ် (ဘီ/၃) ကြာဖြူလမ်း၊ အမှတ် (၁) ရပ်ကွက်၊ ဗိုလ်တထောင်မြို့နယ်',
      dateOfBirth: DateTime(2007,1,15), emergencyContact: '', emergencyPhone: '',
      skillIds: const [], role: UserRole.member, gender: Gender.female,
      nrc: 'လျှောက်ထားဆဲ', ygnId: '13017/01355',
      membershipNo: 'တဖ-ရက/ဗတထ/၅၄', membershipType: MembershipType.official,
    ),

    // m324-m325 — C3/P2/S2 Deputy Section Leaders
    Member(
      id: 'm324', memberNo: 'RC-324',
      nameEn: 'Ma Hnin Eaint Shwe Sin', nameMm: 'မနှင်းအိရွှေစင်',
      rank: MemberRank.deputySectionLeader, unitType: UnitType.section,
      companyNo: 3, platoonNo: 2, sectionNo: 2,
      status: MemberStatus.active, bloodType: BloodType.BP,
      joinDate: DateTime(2021,1,24), currentRankDate: DateTime(2025,1,1),
      phone: '09 260 213 636', email: '',
      address: 'အမှတ် (၁၂၉၁) သဒ္ဒါရုံ (၁) လမ်း၊ အမှတ် (၂) ရပ်ကွက်၊ သာကေတမြို့နယ်',
      dateOfBirth: DateTime(2010,4,10), emergencyContact: '', emergencyPhone: '',
      skillIds: const [], role: UserRole.member, gender: Gender.female,
      nrc: '၁၂/သကတ(နိုင်)၂၃၆၉၀၂', ygnId: '13017/02660',
      membershipNo: 'သမ-၉/ဗတထ/ရက', membershipType: MembershipType.probationer,
    ),
    Member(id: 'm325', memberNo: 'RC-325', nameEn: '', nameMm: '', rank: MemberRank.deputySectionLeader, unitType: UnitType.section, companyNo: 3, platoonNo: 2, sectionNo: 2, status: MemberStatus.active, bloodType: BloodType.OP, joinDate: DateTime(2020,1,1), dateOfBirth: DateTime(1990,1,1), phone: '', email: '', address: '', emergencyContact: '', emergencyPhone: '', skillIds: const [], role: UserRole.member, gender: Gender.female),

    // m326-m327 — C3/P2/S1 Privates
    Member(
      id: 'm326', memberNo: 'RC-326',
      nameEn: 'Ma San Thar Win Pyint', nameMm: 'မသဉ္ဇာဝင်းပြည့်',
      rank: MemberRank.private, unitType: UnitType.section,
      companyNo: 3, platoonNo: 2, sectionNo: 1,
      status: MemberStatus.active, bloodType: BloodType.OP,
      joinDate: DateTime(2025,7,4), currentRankDate: DateTime(2025,7,4),
      phone: '09 964 065 725', email: '',
      address: 'ဇေယျာလမ်း၊ အမှတ် (၁၀) ရပ်ကွက်၊ တောင်ဥက္ကလာပမြို့နယ်',
      dateOfBirth: DateTime(2006,11,21), emergencyContact: '', emergencyPhone: '',
      skillIds: const [], role: UserRole.member, gender: Gender.female,
      nrc: '၁၃/လရန(နိုင်)၂၇၀၂၃၇', membershipNo: 'တဖ-ရက/ဗတထ/၁၁၈',
      membershipType: MembershipType.official,
    ),
    Member(
      id: 'm327', memberNo: 'RC-327',
      nameEn: 'Ma Khin Myat Phu', nameMm: 'မခင်မြတ်ဖူး',
      rank: MemberRank.private, unitType: UnitType.section,
      companyNo: 3, platoonNo: 2, sectionNo: 1,
      status: MemberStatus.active, bloodType: BloodType.AP,
      joinDate: DateTime(2025,7,4), currentRankDate: DateTime(2025,7,4),
      phone: '09 781 654 637', email: '',
      address: 'အမှတ် (၁၆၂/၂) ပထမသီရိရိပ်သာ၊ အောက်ကြည့်မြင်တိုင်လမ်း၊ အလုံမြို့နယ်',
      dateOfBirth: DateTime(2007,4,9), emergencyContact: '', emergencyPhone: '',
      skillIds: const [], role: UserRole.member, gender: Gender.female,
      nrc: 'လျှောက်ထားဆဲ', membershipNo: 'တဖ-ရက/ဗတထ/၁၁၇',
      membershipType: MembershipType.official,
    ),

    // m328 — C3/P2/S1 Private — vacant
    Member(id: 'm328', memberNo: 'RC-328', nameEn: '', nameMm: '', rank: MemberRank.private, unitType: UnitType.section, companyNo: 3, platoonNo: 2, sectionNo: 1, status: MemberStatus.active, bloodType: BloodType.OP, joinDate: DateTime(2020,1,1), dateOfBirth: DateTime(1990,1,1), phone: '', email: '', address: '', emergencyContact: '', emergencyPhone: '', skillIds: const [], role: UserRole.member, gender: Gender.female),

    // m329-m331 — C3/P2/S2 Privates — all vacant
    Member(id: 'm329', memberNo: 'RC-329', nameEn: '', nameMm: '', rank: MemberRank.private, unitType: UnitType.section, companyNo: 3, platoonNo: 2, sectionNo: 2, status: MemberStatus.active, bloodType: BloodType.OP, joinDate: DateTime(2020,1,1), dateOfBirth: DateTime(1990,1,1), phone: '', email: '', address: '', emergencyContact: '', emergencyPhone: '', skillIds: const [], role: UserRole.member, gender: Gender.female),
    Member(id: 'm330', memberNo: 'RC-330', nameEn: '', nameMm: '', rank: MemberRank.private, unitType: UnitType.section, companyNo: 3, platoonNo: 2, sectionNo: 2, status: MemberStatus.active, bloodType: BloodType.OP, joinDate: DateTime(2020,1,1), dateOfBirth: DateTime(1990,1,1), phone: '', email: '', address: '', emergencyContact: '', emergencyPhone: '', skillIds: const [], role: UserRole.member, gender: Gender.female),
    Member(id: 'm331', memberNo: 'RC-331', nameEn: '', nameMm: '', rank: MemberRank.private, unitType: UnitType.section, companyNo: 3, platoonNo: 2, sectionNo: 2, status: MemberStatus.active, bloodType: BloodType.OP, joinDate: DateTime(2020,1,1), dateOfBirth: DateTime(1990,1,1), phone: '', email: '', address: '', emergencyContact: '', emergencyPhone: '', skillIds: const [], role: UserRole.member, gender: Gender.female),

    // ─────────────────────────────────────────────────────────
    // COMPANY 4 — Intentionally empty for now.
    // No mock data entries. Structure, permissions, and rank/unit
    // logic (UnitType.company/platoon, companyNo: 4, the Company 4
    // filter option, permission scope rules, etc.) all remain fully
    // intact elsewhere in the app — only the placeholder data here
    // was removed. To re-add Company 4 later, copy the Company 1 or
    // Company 3 block's structure (Commander → Deputy → Sgt Major →
    // Platoons → Sections → Privates) with companyNo: 4.
    // ─────────────────────────────────────────────────────────
  ];
}

// ═══════════════════════════════════════════════════════════════
// MOCK SKILLS
// ═══════════════════════════════════════════════════════════════
class MockSkills {
  static const List<Skill> all = [
    Skill(id: 'sk1', nameEn: 'First Aid Level 1', nameMm: 'အသက်ဆယ်ယူ အဆင့် ၁', category: 'Medical', expiryMonths: 24),
    Skill(id: 'sk2', nameEn: 'First Aid Level 2', nameMm: 'အသက်ဆယ်ယူ အဆင့် ၂', category: 'Medical', expiryMonths: 24),
    Skill(id: 'sk3', nameEn: 'CPR Certified', nameMm: 'CPR လက်မှတ်', category: 'Medical', expiryMonths: 12),
    Skill(id: 'sk4', nameEn: 'Disaster Management', nameMm: 'ဘေးအန္တရာယ် စီမံခန့်ခွဲမှု', category: 'Disaster'),
    Skill(id: 'sk5', nameEn: 'Leadership', nameMm: 'ခေါင်းဆောင်မှု', category: 'Administrative'),
  ];

  static Skill? findById(String id) {
    try { return all.firstWhere((s) => s.id == id); }
    catch (_) { return null; }
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK DUTIES — empty until real data entered via the app
// (Matches Module 3 placeholder convention)
// ═══════════════════════════════════════════════════════════════
class MockDuties {
  // In-memory store — resets on app restart, replaced by Supabase in
  // Module 16. Seeded with a mix of upcoming, ongoing, and completed
  // duties using real Company 1/3 members so the Duties module has
  // something meaningful to display and test against.
  static final List<Duty> all = _seedDuties();

  static List<Duty> _seedDuties() {
    final now = DateTime.now();
    DateTime d(int dayOffset) =>
        DateTime(now.year, now.month, now.day + dayOffset);

    DutyMember accepted(String memberId, DutyRoleInDuty role) => DutyMember(
          memberId: memberId,
          roleInDuty: role,
          status: DutyAssignmentStatus.accepted,
          assignedAt: d(-3),
          respondedAt: d(-2),
        );

    DutyMember pending(String memberId, DutyRoleInDuty role) => DutyMember(
          memberId: memberId,
          roleInDuty: role,
          status: DutyAssignmentStatus.pending,
          assignedAt: d(-1),
        );

    DutyMember completedAssignment(String memberId, DutyRoleInDuty role) =>
        DutyMember(
          memberId: memberId,
          roleInDuty: role,
          status: DutyAssignmentStatus.completed,
          assignedAt: d(-10),
          respondedAt: d(-9),
        );

    return [
      // Upcoming regular duty — Company 1, Platoon 1
      Duty(
        id: 'duty1',
        title: 'Township Health Fair — First Aid Support',
        titleMm: 'မြို့နယ်ကျန်းမာရေးပွဲ — ရှေးဦးပြုစုထောက်ပံ့မှု',
        type: DutyType.firstAid,
        scale: DutyScale.regular,
        date: d(3),
        startHour: 8, startMinute: 0,
        endHour: 16, endMinute: 0,
        location: 'Botahtaung Township Hall',
        members: [
          accepted('m103', DutyRoleInDuty.officer),
          accepted('m107', DutyRoleInDuty.member),
          pending('m105', DutyRoleInDuty.member),
        ],
        status: DutyStatus.upcoming,
        description: 'Standard first aid coverage for the township health fair.',
      ),

      // Upcoming emergency duty — Company 3
      Duty(
        id: 'duty2',
        title: 'Flood Response Standby',
        titleMm: 'ရေကြီးရေလျှံ အရေးပေါ်အသင့်ရှိမှု',
        type: DutyType.disaster,
        scale: DutyScale.regular,
        date: d(1),
        startHour: 6, startMinute: 0,
        endHour: 18, endMinute: 0,
        location: 'Pazundaung Creek Area',
        members: [
          accepted('m304', DutyRoleInDuty.officer),
          accepted('m306', DutyRoleInDuty.member),
          accepted('m308', DutyRoleInDuty.member),
        ],
        status: DutyStatus.upcoming,
        description: 'Monitoring water levels, on standby for evacuation support.',
      ),

      // Ongoing duty — today
      Duty(
        id: 'duty3',
        title: 'Blood Donation Drive',
        titleMm: 'သွေးလှူဒါန်းမှုအခမ်းအနား',
        type: DutyType.bloodDonation,
        scale: DutyScale.regular,
        date: d(0),
        startHour: 9, startMinute: 0,
        endHour: 15, endMinute: 0,
        location: 'Brigade Office Compound',
        members: [
          accepted('m101', DutyRoleInDuty.commander),
          accepted('m102', DutyRoleInDuty.officer),
          accepted('m106', DutyRoleInDuty.member),
          accepted('m118', DutyRoleInDuty.member),
        ],
        status: DutyStatus.ongoing,
        description: 'Quarterly blood donation drive in partnership with the regional blood bank.',
      ),

      // Completed duty — last week
      Duty(
        id: 'duty4',
        title: 'School Safety Patrol',
        titleMm: 'ကျောင်းဘေးကင်းရေးကင်းလှည့်ခြင်း',
        type: DutyType.patrol,
        scale: DutyScale.regular,
        date: d(-7),
        startHour: 7, startMinute: 0,
        endHour: 9, endMinute: 0,
        location: 'No. 1 Basic Education School',
        members: [
          completedAssignment('m120', DutyRoleInDuty.officer),
          completedAssignment('m113', DutyRoleInDuty.member),
        ],
        status: DutyStatus.completed,
        description: 'Morning school crossing patrol — completed without incident.',
      ),

      // Completed emergency duty — large scale, last month
      Duty(
        id: 'duty5',
        title: 'New Year Festival Crowd Safety',
        titleMm: 'နှစ်ဆက်ပွဲတော် လူစုလူပေါင်းဘေးကင်းရေး',
        type: DutyType.eventMedical,
        scale: DutyScale.largeScale,
        date: d(-30),
        startHour: 18, startMinute: 0,
        endHour: 23, endMinute: 30,
        location: 'Botahtaung Pagoda Festival Grounds',
        members: [
          completedAssignment('m1', DutyRoleInDuty.commander),
          completedAssignment('m101', DutyRoleInDuty.officer),
          completedAssignment('m302', DutyRoleInDuty.officer),
          completedAssignment('m109', DutyRoleInDuty.member),
          completedAssignment('m312', DutyRoleInDuty.member),
        ],
        status: DutyStatus.completed,
        description: 'Large-scale festival medical and crowd safety coverage.',
        isEvent: true,
      ),

      // Upcoming large-scale event — Charity Marathon (links to an
      // Event with positions — see MockEvents below)
      Duty(
        id: 'duty7',
        title: 'Botahtaung Charity Marathon — Medical Coverage',
        titleMm: 'ဗိုလ်တထောင် မဟာမိတ် မာရသွန် — ကျန်းမာရေးထောက်ပံ့မှု',
        type: DutyType.eventMedical,
        scale: DutyScale.largeScale,
        date: d(14),
        startHour: 5, startMinute: 0,
        endHour: 11, endMinute: 0,
        location: 'Botahtaung Township — Strand Road Route',
        members: [
          accepted('m1', DutyRoleInDuty.commander),
          accepted('m101', DutyRoleInDuty.officer),
          accepted('m302', DutyRoleInDuty.officer),
          pending('m109', DutyRoleInDuty.member),
          accepted('m120', DutyRoleInDuty.member),
          pending('m306', DutyRoleInDuty.member),
        ],
        status: DutyStatus.upcoming,
        description: 'Medical and safety coverage along the marathon route, with aid stations and a command post.',
        isEvent: true,
        eventId: 'event1',
      ),

      // Cancelled duty — example
      Duty(
        id: 'duty6',
        title: 'Joint Training Exercise',
        titleMm: 'ပူးတွဲလေ့ကျင့်ခန်း',
        type: DutyType.training,
        scale: DutyScale.regular,
        date: d(-2),
        startHour: 13, startMinute: 0,
        endHour: 16, endMinute: 0,
        location: 'Brigade Training Hall',
        members: [
          DutyMember(
            memberId: 'm118',
            roleInDuty: DutyRoleInDuty.officer,
            status: DutyAssignmentStatus.rejected,
            assignedAt: d(-5),
            respondedAt: d(-4),
            rejectionReason: 'Venue unavailable — rescheduling needed.',
          ),
        ],
        status: DutyStatus.cancelled,
        description: 'Cancelled due to venue conflict.',
      ),
    ];
  }

  static Duty? findById(String id) {
    try {
      return all.firstWhere((d) => d.id == id);
    } catch (_) {
      return null;
    }
  }

  /// Adds a newly created duty to the in-memory list, so it actually
  /// shows up in the Duties screen this session. Replaced by a real
  /// Supabase insert in Module 16.
  static void add(Duty duty) {
    all.add(duty);
  }

  static void update(Duty updated) {
    final index = all.indexWhere((d) => d.id == updated.id);
    if (index != -1) {
      all[index] = updated;
    } else {
      all.add(updated);
    }
  }

  /// All DutyMember assignment records for `memberId`, paired with
  /// the Duty they belong to (most recent first).
  static List<({Duty duty, DutyMember assignment})> getMemberDuties(String memberId) {
    final results = <({Duty duty, DutyMember assignment})>[];
    for (final duty in all) {
      final assignment =
          duty.members.where((dm) => dm.memberId == memberId).firstOrNull;
      if (assignment != null) {
        results.add((duty: duty, assignment: assignment));
      }
    }
    results.sort((a, b) => b.duty.date.compareTo(a.duty.date));
    return results;
  }

  /// Duties visible to `member` based on unit scope — reuses the same
  /// company-scoping convention as other Module 4/5 screens. Brigade
  /// Office sees everything; everyone else sees duties where at least
  /// one assigned member shares their company (a reasonable proxy
  /// for "duties relevant to my unit" until a dedicated unit field
  /// is added to Duty in a later module).
  static List<Duty> visibleTo(Member viewer) {
    if (viewer.unitType == UnitType.brigadeOffice) return all;
    if (PermissionService.hasAdminOrMasterAccess(viewer)) return all;

    return all.where((duty) {
      return duty.members.any((dm) {
        final m = MockMembers.findById(dm.memberId);
        return m != null && m.companyNo == viewer.companyNo;
      });
    }).toList();
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK MEETINGS — empty until real data entered via the app
// ═══════════════════════════════════════════════════════════════
class MockMeetings {
  // In-memory store — resets on app restart, replaced by Supabase in
  // Module 16. Seeded with a mix of meeting types/statuses using real
  // Company 1/3 and Brigade Office members.
  static final List<Meeting> all = _seedMeetings();

  static List<Meeting> _seedMeetings() {
    final now = DateTime.now();
    DateTime d(int dayOffset) =>
        DateTime(now.year, now.month, now.day + dayOffset);

    return [
      // Upcoming officer meeting — Brigade-wide
      Meeting(
        id: 'meeting1',
        title: 'Quarterly Officer Meeting',
        titleMm: 'သုံးလပတ် အရာရှိများအစည်းအဝေး',
        type: MeetingType.officer,
        date: d(5),
        timeHour: 14, timeMinute: 0,
        location: 'Brigade Office Conference Room',
        invitedMemberIds: const ['m1', 'm2', 'm101', 'm102', 'm302'],
        attendedMemberIds: const [],
        minimumRank: MemberRank.platoonLeader,
        status: MeetingStatus.scheduled,
        tasks: const [],
        createdAt: d(-3),
        meetingNumber: 3,
        meetingYear: now.year,
        organizerMemberId: 'm1',
        recorderMemberId: 'm6',
        agendaItems: const [
          AgendaItem(
            id: 'agenda1_1', meetingId: 'meeting1', order: 1,
            topic: 'Q2 Duty Roster Review',
            presenterMemberId: 'm2',
          ),
          AgendaItem(
            id: 'agenda1_2', meetingId: 'meeting1', order: 2,
            topic: 'Upcoming Charity Marathon — Staffing',
            presenterMemberId: 'm1',
          ),
        ],
      ),

      // Completed general meeting — Company 1
      Meeting(
        id: 'meeting2',
        title: 'Company 1 Monthly Meeting',
        titleMm: 'တပ်ခွဲ (၁) လစဉ်အစည်းအဝေး',
        type: MeetingType.general,
        date: d(-20),
        timeHour: 10, timeMinute: 0,
        location: 'Company 1 Office',
        invitedMemberIds: const ['m101', 'm102', 'm103', 'm106', 'm107', 'm118', 'm119'],
        attendedMemberIds: const ['m101', 'm102', 'm103', 'm106', 'm118'],
        excusedMemberIds: const ['m107'],
        absentMemberIds: const ['m119'],
        status: MeetingStatus.published,
        tasks: [
          MeetingTask(
            id: 'task2_1', meetingId: 'meeting2',
            title: 'Submit updated equipment inventory',
            assignedMemberId: 'm106',
            dueDate: d(-10),
            isCompleted: true,
            completedAt: d(-12),
            isVerified: true,
          ),
          MeetingTask(
            id: 'task2_2', meetingId: 'meeting2',
            title: 'Confirm Platoon 2 section leader vacancy fill',
            assignedMemberId: 'm118',
            dueDate: d(-5),
            isCompleted: false,
            isVerified: false,
          ),
        ],
        createdAt: d(-23),
        meetingNumber: 4,
        meetingYear: now.year,
        organizerMemberId: 'm101',
        recorderMemberId: 'm106',
        approvedByMemberId: 'm2',
        agendaItems: [
          AgendaItem(
            id: 'agenda2_1', meetingId: 'meeting2', order: 1,
            topic: 'Equipment Inventory Update',
            presenterMemberId: 'm106',
            discussionEntries: [
              DiscussionEntry(id: 'disc1', speakerMemberId: 'm106', comment: 'Current stock is short on stretchers — only 5 of 6 accounted for.'),
              DiscussionEntry(id: 'disc2', speakerMemberId: 'm101', comment: 'One stretcher was loaned to Company 3 last month, should be returned by now.'),
              DiscussionEntry(id: 'disc3', speakerMemberId: 'm102', comment: 'Will follow up with Company 3 directly this week.'),
            ],
            decisions: const [
              DecisionEntry(id: 'dec1', decisionText: 'Ko Wai Phyo Paing to submit updated inventory by next week.', approvedByMemberId: 'm101'),
              DecisionEntry(id: 'dec2', decisionText: 'U Aung Wai Htun to recover the loaned stretcher from Company 3.', approvedByMemberId: 'm101'),
            ],
          ),
          AgendaItem(
            id: 'agenda2_2', meetingId: 'meeting2', order: 2,
            topic: 'Platoon 2 Section Leader Vacancy',
            presenterMemberId: 'm118',
            discussionEntries: [
              DiscussionEntry(id: 'disc4', speakerMemberId: 'm118', comment: 'Two candidates from Section 1 have shown interest in the vacancy.'),
              DiscussionEntry(id: 'disc5', speakerMemberId: 'm103', comment: 'Recommend evaluating both on duty performance over the next month before deciding.'),
            ],
            decisions: const [
              DecisionEntry(id: 'dec3', decisionText: 'U Pyae Phyo Aung to confirm a recommendation before the next meeting.', approvedByMemberId: 'm101'),
            ],
          ),
          AgendaItem(
            id: 'agenda2_3', meetingId: 'meeting2', order: 3,
            topic: 'First Aid Level 3 — Company 1 Attendance Authorization',
            presenterMemberId: 'm101',
            discussionEntries: const [
              DiscussionEntry(id: 'disc6', speakerMemberId: 'm101', comment: 'HQ is offering a First Aid Level 3 course next quarter — proposing we send our eligible Level 2 holders.'),
            ],
            decisions: const [
              DecisionEntry(
                id: 'dec4',
                decisionText: 'Company 1 to submit a nomination list of eligible members for the First Aid Level 3 class once scheduled.',
                approvedByMemberId: 'm101',
              ),
            ],
          ),
        ],
        minutes: 'Meeting opened on time with quorum present. Equipment inventory and the Platoon 2 vacancy were the main discussion items. Two action items assigned, see tasks.',
      ),

      // In-progress committee meeting — Brigade Office
      Meeting(
        id: 'meeting3',
        title: 'Investigation Committee Briefing',
        titleMm: 'စုံစမ်းစစ်ဆေးရေး ကော်မတီ ရှင်းလင်းပွဲ',
        type: MeetingType.investigation,
        date: d(0),
        timeHour: 9, timeMinute: 30,
        location: 'Brigade Office Meeting Room',
        invitedMemberIds: const ['m1', 'm2', 'm3'],
        attendedMemberIds: const ['m1', 'm2'],
        status: MeetingStatus.inProgress,
        tasks: const [],
        createdAt: d(-1),
        meetingNumber: 1,
        meetingYear: now.year,
        organizerMemberId: 'm2',
        recorderMemberId: 'm6',
        agendaItems: const [
          AgendaItem(
            id: 'agenda3_1', meetingId: 'meeting3', order: 1,
            topic: 'Case Briefing — Committee Assignment',
            presenterMemberId: 'm2',
          ),
        ],
        linkedInvestigationId: 'inv1',
      ),
    ];
  }

  static Meeting? findById(String id) {
    try {
      return all.firstWhere((m) => m.id == id);
    } catch (_) {
      return null;
    }
  }

  static void add(Meeting meeting) {
    all.add(meeting);
  }

  static void update(Meeting updated) {
    final index = all.indexWhere((m) => m.id == updated.id);
    if (index != -1) {
      all[index] = updated;
    } else {
      all.add(updated);
    }
  }

  /// Meetings visible to `member` — Brigade Office sees everything;
  /// everyone else sees meetings they're invited to, plus meetings
  /// for their own company (proxied via whether any invited member
  /// shares their company — same convention used for MockDuties).
  static List<Meeting> visibleTo(Member viewer) {
    if (viewer.unitType == UnitType.brigadeOffice) return all;
    if (PermissionService.hasAdminOrMasterAccess(viewer)) return all;

    return all.where((meeting) {
      if (meeting.invitedMemberIds.contains(viewer.id)) return true;
      return meeting.invitedMemberIds.any((id) {
        final m = MockMembers.findById(id);
        return m != null && m.companyNo == viewer.companyNo;
      });
    }).toList();
  }

  /// Allocates the next meeting number for `type` within `year`.
  /// Numbering resets to 1 each January, counted separately per
  /// MeetingType, per the locked numbering rule from the document
  /// format spec (e.g. "Officer Meeting No. 3/2026").
  static int nextMeetingNumber(MeetingType type, int year) {
    final sameTypeAndYear = all.where(
      (m) => m.type == type && m.meetingYear == year,
    );
    if (sameTypeAndYear.isEmpty) return 1;
    final maxNumber = sameTypeAndYear
        .map((m) => m.meetingNumber ?? 0)
        .reduce((a, b) => a > b ? a : b);
    return maxNumber + 1;
  }

  /// Finds the most recent meeting of the same type before `date`,
  /// used to auto-pull forward its pending tasks into a new meeting.
  static Meeting? mostRecentOfType(MeetingType type, DateTime beforeDate) {
    final candidates = all
        .where((m) => m.type == type && m.date.isBefore(beforeDate))
        .toList()
      ..sort((a, b) => b.date.compareTo(a.date));
    return candidates.isEmpty ? null : candidates.first;
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK INVESTIGATIONS — empty until real data entered via the app
// ═══════════════════════════════════════════════════════════════
class MockInvestigations {
  // In-memory store — resets on app restart, replaced by Supabase in
  // Module 16. Seeded with one ongoing investigation so the Meetings
  // module's Investigation/Committee meeting-type gating has
  // something real to check against ahead of Module 11 being built.
  static final List<Investigation> all = [
    Investigation(
      id: 'inv1',
      caseNumber: 'INV-2026-01',
      title: 'Conduct review — duty attendance discrepancy',
      description: 'Reviewing repeated unexplained absences from assigned duties.',
      openedDate: DateTime.now().subtract(const Duration(days: 10)),
      status: InvestigationStatus.underInvestigation,
      accusedMemberIds: const ['m119'],
      witnessMemberIds: const ['m107'],
      committeeMemberIds: const ['m2', 'm3', 'm101'],
      recusedMemberIds: const [],
      appealCommitteeMemberIds: const [],
      approvedSealedViewers: const [],
      committeeJoinDates: const {},
      stageLogs: [
        InvestigationStageLog(
          id: 'stage1', investigationId: 'inv1',
          stage: InvestigationStatus.opened,
          timestamp: DateTime.now().subtract(const Duration(days: 10)),
          actionedById: 'm2',
          notes: 'Case opened following a duty roster review flagging repeated absences.',
        ),
        InvestigationStageLog(
          id: 'stage2', investigationId: 'inv1',
          stage: InvestigationStatus.underInvestigation,
          timestamp: DateTime.now().subtract(const Duration(days: 9)),
          actionedById: 'm2',
          notes: 'Committee formed, evidence gathering started.',
        ),
      ],
      attachments: const [],
      isSealed: false,
    ),
  ];

  static Investigation? findById(String id) {
    try {
      return all.firstWhere((i) => i.id == id);
    } catch (_) {
      return null;
    }
  }

  /// Is there any investigation currently in an active stage (not
  /// concluded/closed)? Used to gate Investigation Meeting
  /// availability — only appears when there's something to actually
  /// meet about.
  static bool get hasOngoingInvestigation {
    return all.any((i) =>
        i.status != InvestigationStatus.closed &&
        i.status != InvestigationStatus.concluded &&
        i.status != InvestigationStatus.appealConcluded);
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK COMMITTEES
// Minimal placeholder store — see the Committee model's own comment
// for why this exists ahead of full Class/Investigation modules.
// ═══════════════════════════════════════════════════════════════
class MockCommittees {
  static final List<Committee> all = [
    Committee(
      id: 'committee1',
      name: 'Conduct Review Committee — INV-2026-01',
      purpose: CommitteePurpose.investigation,
      linkedInvestigationId: 'inv1',
      memberIds: const ['m2', 'm3', 'm101'],
      isActive: true,
      formedDate: DateTime.now().subtract(const Duration(days: 9)),
    ),
  ];

  static Committee? findById(String id) {
    try {
      return all.firstWhere((c) => c.id == id);
    } catch (_) {
      return null;
    }
  }

  /// Is there any currently active committee, for any purpose
  /// (investigation, class, disciplinary, or other special
  /// situation)? Used to gate Committee Meeting availability.
  static bool get hasActiveCommittee => all.any((c) => c.isActive);
}

// ═══════════════════════════════════════════════════════════════
// MOCK PUNISHMENTS — empty until real data entered via the app
// ═══════════════════════════════════════════════════════════════
class MockPunishments {
  static final List<Punishment> all = _seedPunishments();

  static List<Punishment> _seedPunishments() {
    final now = DateTime.now();
    return [
      // A standalone verbal warning, unrelated to any investigation.
      Punishment(
        id: 'punish1',
        memberId: 'm119',
        type: PunishmentType.verbalWarning,
        description: 'Repeated late arrival to assigned duties without prior notice.',
        issuedDate: now.subtract(const Duration(days: 45)),
        issuedById: 'm101',
        status: PunishmentStatus.completed,
        isAppealable: false,
      ),
      // Linked to inv1, the seeded ongoing investigation — shows the
      // investigationId connection and an active suspension that's
      // still appealable.
      Punishment(
        id: 'punish2',
        memberId: 'm119',
        type: PunishmentType.suspension,
        description: 'Suspended from duty roster pending outcome of conduct review INV-2026-01.',
        issuedDate: now.subtract(const Duration(days: 8)),
        endDate: now.add(const Duration(days: 22)),
        issuedById: 'm2',
        status: PunishmentStatus.active,
        investigationId: 'inv1',
        isAppealable: true,
      ),
    ];
  }

  static List<Punishment> forMember(String memberId) {
    return all.where((p) => p.memberId == memberId).toList();
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK BLOOD DONORS — empty until real data entered via the app
// ═══════════════════════════════════════════════════════════════
class MockBloodDonors {
  static final List<BloodDonor> all = _seedDonors();

  static List<BloodDonor> _seedDonors() {
    final now = DateTime.now();
    return [
      BloodDonor(
        id: 'donor1',
        nameEn: 'Ko Wai Phyo Paing',
        type: DonorType.internal,
        memberId: 'm106',
        bloodType: BloodType.OP,
        lastDonationDate: now.subtract(const Duration(days: 70)),
        totalDonations: 4,
        phone: '+973 3300 1106',
        isActive: true,
      ),
      BloodDonor(
        id: 'donor2',
        nameEn: 'U Aung Wai Htun',
        type: DonorType.internal,
        memberId: 'm102',
        bloodType: BloodType.AP,
        lastDonationDate: now.subtract(const Duration(days: 130)),
        totalDonations: 9,
        phone: '+973 3300 1102',
        isActive: true,
      ),
      BloodDonor(
        id: 'donor3',
        nameEn: 'Daw Khin Hnin Yee',
        type: DonorType.external,
        bloodType: BloodType.OM,
        lastDonationDate: now.subtract(const Duration(days: 200)),
        totalDonations: 2,
        phone: '+973 3399 8821',
        isActive: true,
      ),
      BloodDonor(
        id: 'donor4',
        nameEn: 'Ko Min Thu',
        type: DonorType.external,
        bloodType: BloodType.BP,
        lastDonationDate: null, // never donated yet, but registered as eligible
        totalDonations: 0,
        phone: '+973 3399 4471',
        isActive: true,
      ),
      BloodDonor(
        id: 'donor5',
        nameEn: 'Ko Aung Bhone Khant',
        type: DonorType.internal,
        memberId: 'm107',
        bloodType: BloodType.ABP,
        lastDonationDate: now.subtract(const Duration(days: 40)),
        totalDonations: 6,
        phone: '+973 3300 1107',
        isActive: false, // recently donated, in cooldown — not currently eligible
      ),
    ];
  }

  static BloodDonor? findById(String id) {
    try {
      return all.firstWhere((d) => d.id == id);
    } catch (_) {
      return null;
    }
  }

  static List<BloodDonor> eligibleByBloodType(BloodType type) {
    return all.where((d) => d.bloodType == type && d.isActive).toList();
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK NOTIFICATIONS — empty until real data entered via the app
// ═══════════════════════════════════════════════════════════════
class MockNotifications {
  // In-memory store — resets on app restart, replaced by Supabase in
  // Module 16.
  static final List<AppNotification> all = _seedNotifications();

  static List<AppNotification> _seedNotifications() {
    final now = DateTime.now();
    return [
      AppNotification(
        id: 'notif1',
        recipientId: 'm105',
        title: 'Enrollment request sent',
        body: 'Your request to join "First Aid Level 2 Refresher" is pending instructor approval.',
        type: NotificationType.classEvent,
        priority: NotificationPriority.normal,
        isRead: false,
        createdAt: now.subtract(const Duration(days: 2)),
        routeTo: 'class1',
      ),
      AppNotification(
        id: 'notif2',
        recipientId: 'm101',
        title: 'New join request',
        body: 'Ko Aung Nanda requested to join "First Aid Level 2 Refresher".',
        type: NotificationType.classEvent,
        priority: NotificationPriority.normal,
        isRead: false,
        createdAt: now.subtract(const Duration(days: 2)),
        routeTo: 'class1',
      ),
      AppNotification(
        id: 'notif3',
        recipientId: 'm106',
        title: 'Quarterly Officer Meeting reminder',
        body: 'The Quarterly Officer Meeting is coming up — check the agenda before attending.',
        type: NotificationType.meeting,
        priority: NotificationPriority.high,
        isRead: true,
        createdAt: now.subtract(const Duration(days: 1)),
        routeTo: 'meeting1',
      ),
      AppNotification(
        id: 'notif4',
        recipientId: 'm2',
        title: 'Closure report edit request',
        body: 'A request to edit the locked closure report for "Disaster Management Fundamentals" is awaiting your review.',
        type: NotificationType.system,
        priority: NotificationPriority.normal,
        isRead: false,
        createdAt: now.subtract(const Duration(days: 1)),
      ),
    ];
  }

  static List<AppNotification> forMember(String memberId) {
    return all.where((n) => n.recipientId == memberId).toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  static int unreadCount(String memberId) {
    return all.where((n) => n.recipientId == memberId && !n.isRead).length;
  }

  static void add(AppNotification notification) {
    all.add(notification);
  }

  /// Sends an availability-change notification up the FULL chain of
  /// command from `member` to Brigade Office — not just the immediate
  /// higher rank. Used when a member changes their own short-term
  /// Available/Not Available status, which applies immediately with
  /// no approval needed; this is purely an FYI to leadership.
  ///
  /// Chain walked: member's direct higher rank → their higher rank →
  /// ... → Brigade Office. Determined structurally from unit
  /// assignment (section → platoon → company → brigade), not by
  /// walking actual person-to-person rank order, since multiple
  /// people can hold the same supervisory tier.
  static void notifyChainOfCommandOfAvailabilityChange({
    required Member member,
    required bool isNowAvailable,
  }) {
    final recipients = _chainOfCommandFor(member);
    final statusText = isNowAvailable ? 'Available' : 'Not Available';

    for (final recipient in recipients) {
      add(AppNotification(
        id: 'notif_${DateTime.now().microsecondsSinceEpoch}_${recipient.id}',
        recipientId: recipient.id,
        title: 'Availability Update',
        body: '${member.nameEn} (${member.rankNameEn}) marked themselves $statusText.',
        type: NotificationType.availability,
        priority: NotificationPriority.normal,
        isRead: false,
        createdAt: DateTime.now(),
        routeTo: 'members/${member.id}',
      ));
    }
  }

  /// Walks up the chain of command for `member`: direct higher-rank
  /// supervisors at section → platoon → company level, plus all of
  /// Brigade Office at the top, regardless of how many tiers exist
  /// in between. Skips levels that don't apply (e.g. a member with no
  /// platoon assignment skips straight to company/brigade).
  static List<Member> _chainOfCommandFor(Member member) {
    final all = MockMembers.all.where((m) => m.nameEn.isNotEmpty);
    final chain = <Member>[];

    void addIfNotSelf(Iterable<Member> candidates) {
      for (final c in candidates) {
        if (c.id != member.id && !chain.any((existing) => existing.id == c.id)) {
          chain.add(c);
        }
      }
    }

    // Section level (Deputy Section Leader -> Section Leader)
    if (member.sectionNo != null) {
      addIfNotSelf(all.where((m) =>
          m.companyNo == member.companyNo &&
          m.platoonNo == member.platoonNo &&
          m.sectionNo == member.sectionNo &&
          m.rank == MemberRank.sectionLeader));
    }

    // Platoon level (Platoon Sergeant, Platoon Leader)
    if (member.platoonNo != null) {
      addIfNotSelf(all.where((m) =>
          m.companyNo == member.companyNo &&
          m.platoonNo == member.platoonNo &&
          (m.rank == MemberRank.platoonSergeant ||
              m.rank == MemberRank.platoonLeader)));
    }

    // Company level (Company Sergeant Major, Deputy/Company Commander)
    if (member.companyNo != null) {
      addIfNotSelf(all.where((m) =>
          m.companyNo == member.companyNo &&
          (m.rank == MemberRank.companySergeantMajor ||
              m.rank == MemberRank.deputyCompanyCommander ||
              m.rank == MemberRank.companyCommander)));
    }

    // Brigade Office — always included at the top of the chain
    addIfNotSelf(all.where((m) => m.unitType == UnitType.brigadeOffice));

    return chain;
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK AVAILABILITY — empty until real data entered via the app
// ═══════════════════════════════════════════════════════════════
class MockAvailability {
  // In-memory store — resets on app restart, replaced by Supabase in
  // Module 16. Seeded with a few sample entries so the calendar UI has
  // something to render during development.
  static final List<AvailabilityEntry> _entries = _seedEntries();

  static List<AvailabilityEntry> _seedEntries() {
    final now = DateTime.now();
    DateTime d(int dayOffset) =>
        DateTime(now.year, now.month, now.day + dayOffset);

    // Real (non-vacant) members across Company 1 and Company 3 —
    // used to seed a deterministic but varied pattern so the unit
    // summary breakdown (by company/platoon/section) and the day
    // trend chart (today/week/month) have meaningful data to show.
    const company1MemberIds = [
      'm101', 'm102', 'm103', 'm105', 'm106', 'm107', 'm108', 'm109',
      'm110', 'm111', 'm112', 'm113', 'm114', 'm115', 'm116', 'm117',
      'm118', 'm119', 'm120', 'm121', 'm122', 'm124', 'm125', 'm126',
      'm127',
    ];
    const company3MemberIds = [
      'm302', 'm303', 'm304', 'm305', 'm306', 'm307', 'm308', 'm309',
      'm310', 'm311', 'm312', 'm313', 'm314', 'm315', 'm318', 'm319',
      'm320', 'm321', 'm322', 'm323', 'm324', 'm326', 'm327',
    ];
    final allIds = [...company1MemberIds, ...company3MemberIds];

    final entries = <AvailabilityEntry>[];
    var counter = 0;

    // Deterministic pattern across a -10..+20 day window (covers last
    // week, this week, and this month comfortably either side of
    // today): each member has a short "not available" block on a
    // day offset derived from their position in the list, so the
    // pattern is spread out rather than everyone clustering on the
    // same days. Roughly 1 in 4 members get a block in any given week.
    for (var i = 0; i < allIds.length; i++) {
      final memberId = allIds[i];

      // Stagger start day using member index so blocks spread across
      // the whole window instead of bunching up.
      final startOffset = -10 + ((i * 3) % 28);
      final blockLength = 1 + (i % 3); // 1, 2, or 3 day blocks
      final groupId = 'rg_seed_$i';

      for (var dayInBlock = 0; dayInBlock < blockLength; dayInBlock++) {
        counter++;
        entries.add(AvailabilityEntry(
          id: 'ae_seed_$counter',
          memberId: memberId,
          date: d(startOffset + dayInBlock),
          status: DayAvailabilityStatus.notAvailable,
          rangeGroupId: blockLength > 1 ? groupId : null,
        ));
      }
    }

    return entries;
  }

  static List<AvailabilityEntry> forMember(String memberId) {
    return _entries.where((e) => e.memberId == memberId).toList();
  }

  static List<AvailabilityEntry> forMemberInMonth(
    String memberId,
    int year,
    int month,
  ) {
    return _entries
        .where((e) =>
            e.memberId == memberId &&
            e.date.year == year &&
            e.date.month == month)
        .toList();
  }

  static List<AvailabilityEntry> forMembersOnDate(
    List<String> memberIds,
    DateTime date,
  ) {
    return _entries
        .where((e) => memberIds.contains(e.memberId) && e.isOnDate(date))
        .toList();
  }

  /// Set a single day's status directly (Master Access/Admin path, or
  /// applying an already-approved request). Replaces any existing
  /// entry for that member+date.
  static void setDay({
    required String memberId,
    required DateTime date,
    required DayAvailabilityStatus status,
    String? reason,
    String? rangeGroupId,
  }) {
    _entries.removeWhere((e) => e.memberId == memberId && e.isOnDate(date));
    _entries.add(AvailabilityEntry(
      id: 'ae_${DateTime.now().microsecondsSinceEpoch}',
      memberId: memberId,
      date: DateTime(date.year, date.month, date.day),
      status: status,
      rangeGroupId: rangeGroupId,
      reason: reason,
    ));
  }

  /// Set a date range (inclusive) all at once, sharing one rangeGroupId
  /// so they collapse into a single visual block.
  static void setRange({
    required String memberId,
    required DateTime startDate,
    required DateTime endDate,
    required DayAvailabilityStatus status,
    String? reason,
  }) {
    final groupId = 'rg_${DateTime.now().microsecondsSinceEpoch}';
    var current = DateTime(startDate.year, startDate.month, startDate.day);
    final end = DateTime(endDate.year, endDate.month, endDate.day);
    while (!current.isAfter(end)) {
      setDay(
        memberId: memberId,
        date: current,
        status: status,
        reason: reason,
        rangeGroupId: groupId,
      );
      current = current.add(const Duration(days: 1));
    }
  }

  /// Clear a single day back to default (no entry = implicitly
  /// available, per the existing isAvailable/status fields).
  static void clearDay({required String memberId, required DateTime date}) {
    _entries.removeWhere((e) => e.memberId == memberId && e.isOnDate(date));
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK CLASSES & TRAINING
// In-memory store — resets on app restart, replaced by Supabase in
// Module 16. Seeded with real Company 1/3 members and Brigade
// Office instructors so the Classes module has something real to
// display and test against.
// ═══════════════════════════════════════════════════════════════
class MockClasses {
  static final List<TrainingClass> all = _seedClasses();

  static List<TrainingClass> _seedClasses() {
    final now = DateTime.now();
    DateTime d(int dayOffset) =>
        DateTime(now.year, now.month, now.day + dayOffset);

    return [
      // Upcoming class — Company 1, with committee, budget, sessions,
      // and a video lesson link.
      TrainingClass(
        id: 'class1',
        title: 'First Aid Level 2 Refresher',
        titleMm: 'အသက်ဆယ်ယူ အဆင့် ၂ ပြန်လည်လေ့ကျင့်ခြင်း',
        type: ClassType.workshop,
        category: 'Medical',
        description: 'Refresher course covering updated first aid protocols, required for First Aid Level 2 certification renewal.',
        instructorId: 'm101',
        instructorName: 'U Aung Wai Htun',
        isExternalInstructor: false,
        startDate: d(7),
        endDate: d(9),
        location: 'Company 1 Training Hall',
        maxParticipants: 20,
        enrolledMemberIds: const ['m103', 'm106', 'm107', 'm118'],
        status: ClassStatus.open,
        requiredSkillIds: const ['sk1'], // First Aid Level 1
        awardedSkillIds: const ['sk2'], // First Aid Level 2
        issuesCertificate: true,
        hasCommittee: true,
        committee: const [
          ClassCommitteeMember(memberId: 'm101', role: 'Chairperson'),
          ClassCommitteeMember(memberId: 'm102', role: 'Coordinator'),
          ClassCommitteeMember(memberId: 'm106', role: 'Logistics'),
        ],
        budget: ClassBudget(
          id: 'budget1',
          classId: 'class1',
          totalAmount: 150000,
          fundingSource: FundingSource.organizationFund,
          categoryAllocations: const {
            'Materials': 60000,
            'Refreshments': 50000,
            'Instructor Honorarium': 40000,
          },
          memberLunchAllowed: true,
          memberTravelAllowed: false,
          approvalStatus: 'approved',
          expenses: [
            ClassExpense(
              id: 'exp1', classId: 'class1', category: 'Materials',
              amount: 35000, date: d(-2), paidTo: 'Bahosi Medical Supplies',
              description: 'Bandages, splints, training manikins rental',
              loggedById: 'm106', status: ExpenseStatus.approved,
              paymentStatus: PaymentStatus.paid,
            ),
          ],
        ),
        timetable: [
          ClassSession(
            id: 'session1_1', classId: 'class1', sessionNumber: 1,
            topic: 'Updated CPR & AED Protocols', date: d(7),
            startHour: 9, startMinute: 0, endHour: 12, endMinute: 0,
            location: 'Company 1 Training Hall', facilitator: 'U Aung Wai Htun',
            status: 'scheduled',
          ),
          ClassSession(
            id: 'session1_2', classId: 'class1', sessionNumber: 2,
            topic: 'Trauma & Wound Management', date: d(8),
            startHour: 9, startMinute: 0, endHour: 12, endMinute: 0,
            location: 'Company 1 Training Hall', facilitator: 'U Aung Wai Htun',
            status: 'scheduled',
          ),
          ClassSession(
            id: 'session1_3', classId: 'class1', sessionNumber: 3,
            topic: 'Practical Assessment', date: d(9),
            startHour: 9, startMinute: 0, endHour: 12, endMinute: 0,
            location: 'Company 1 Training Hall', facilitator: 'U Aung Wai Htun',
            status: 'scheduled',
          ),
        ],
        videoUrl: 'https://youtu.be/dQw4w9WgXcQ',
      ),

      // Completed class — for testing the Closure Report / Post-
      // Training Report screens against real outcome data.
      TrainingClass(
        id: 'class2',
        title: 'Disaster Management Fundamentals',
        titleMm: 'ဘေးအန္တရာယ် စီမံခန့်ခွဲမှု အခြေခံသင်တန်း',
        type: ClassType.classRoom,
        category: 'Disaster',
        description: 'Foundational training on disaster response coordination and the brigade\'s DANA reporting process.',
        instructorId: 'm2',
        instructorName: 'U Aung Wai Htun',
        isExternalInstructor: false,
        startDate: d(-30),
        endDate: d(-28),
        location: 'Brigade Office Conference Room',
        maxParticipants: 15,
        enrolledMemberIds: const ['m101', 'm103', 'm302', 'm304'],
        status: ClassStatus.completed,
        requiredSkillIds: const [],
        awardedSkillIds: const ['sk4'], // Disaster Management
        issuesCertificate: true,
        hasCommittee: false,
        committee: const [],
        timetable: [
          ClassSession(
            id: 'session2_1', classId: 'class2', sessionNumber: 1,
            topic: 'Disaster Response Coordination', date: d(-30),
            startHour: 13, startMinute: 0, endHour: 16, endMinute: 0,
            location: 'Brigade Office Conference Room', facilitator: 'U Aung Wai Htun',
            status: 'completed',
          ),
          ClassSession(
            id: 'session2_2', classId: 'class2', sessionNumber: 2,
            topic: 'DANA Reporting Workshop', date: d(-28),
            startHour: 13, startMinute: 0, endHour: 16, endMinute: 0,
            location: 'Brigade Office Conference Room', facilitator: 'U Aung Wai Htun',
            status: 'completed',
          ),
        ],
        feedbackQuestions: const [
          FeedbackQuestion(id: 'fq1', text: 'How would you rate the overall quality of this class?', type: FeedbackQuestionType.rating),
          FeedbackQuestion(id: 'fq2', text: 'How clear was the instructor\'s explanation?', type: FeedbackQuestionType.rating),
          FeedbackQuestion(id: 'fq3', text: 'What topics would you like covered in future training?', type: FeedbackQuestionType.text),
        ],
      ),
    ];
  }

  static TrainingClass? findById(String id) {
    try {
      return all.firstWhere((c) => c.id == id);
    } catch (_) {
      return null;
    }
  }

  static void add(TrainingClass trainingClass) {
    all.add(trainingClass);
  }

  static void update(TrainingClass updated) {
    final index = all.indexWhere((c) => c.id == updated.id);
    if (index != -1) {
      all[index] = updated;
    } else {
      all.add(updated);
    }
  }

  /// Classes visible to `viewer` — Brigade Office sees everything;
  /// everyone else sees classes hosted by their own company, plus
  /// any class they're enrolled in regardless of company (so a
  /// member who joined a brigade-wide class still sees it).
  static List<TrainingClass> visibleTo(Member viewer) {
    if (viewer.unitType == UnitType.brigadeOffice) return all;
    if (PermissionService.hasAdminOrMasterAccess(viewer)) return all;

    return all.where((c) {
      if (c.enrolledMemberIds.contains(viewer.id)) return true;
      final instructor = MockMembers.findById(c.instructorId);
      if (instructor != null && instructor.companyNo == viewer.companyNo) return true;
      return c.committee.any((cm) {
        final m = MockMembers.findById(cm.memberId);
        return m != null && m.companyNo == viewer.companyNo;
      });
    }).toList();
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK ENROLLMENT REQUESTS
// ═══════════════════════════════════════════════════════════════
class MockEnrollmentRequests {
  static final List<EnrollmentRequest> all = _seedRequests();

  static List<EnrollmentRequest> _seedRequests() {
    final now = DateTime.now();
    return [
      // m105 (Private, Company 1) requesting to join class1 (First
      // Aid Level 2 Refresher) — not yet enrolled, not already
      // certified — tests the Manage Enrollment approve/deny flow.
      EnrollmentRequest(
        id: 'enroll1',
        classId: 'class1',
        memberId: 'm105',
        reason: 'Want to refresh my certification before it expires next month.',
        status: EnrollmentRequestStatus.pending,
        requestedAt: now.subtract(const Duration(days: 2)),
      ),
    ];
  }

  static void add(EnrollmentRequest request) {
    all.add(request);
  }

  static void update(EnrollmentRequest updated) {
    final index = all.indexWhere((r) => r.id == updated.id);
    if (index != -1) {
      all[index] = updated;
    } else {
      all.add(updated);
    }
  }

  static List<EnrollmentRequest> pendingForClass(String classId) {
    return all
        .where((r) => r.classId == classId && r.status == EnrollmentRequestStatus.pending)
        .toList();
  }

  static List<EnrollmentRequest> submittedBy(String memberId) {
    final result = all.where((r) => r.memberId == memberId).toList();
    result.sort((a, b) => b.requestedAt.compareTo(a.requestedAt));
    return result;
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK CLASS FEEDBACK
// ═══════════════════════════════════════════════════════════════
// ═══════════════════════════════════════════════════════════════
// MOCK SESSION ATTENDANCE
// Real per-member, per-session check-in records — what the Closure
// Report's per-member attendance rates are computed from. In-memory
// store, resets on app restart, replaced by Supabase in Module 16.
// ═══════════════════════════════════════════════════════════════
class MockSessionAttendance {
  static final List<SessionAttendance> all = _seedAttendance();

  static List<SessionAttendance> _seedAttendance() {
    // Realistic, varied attendance for class2 (Disaster Management
    // Fundamentals, completed) so the Closure Report's per-member
    // attendance rates have something meaningful to show:
    //   m101 — attended both sessions (100%)
    //   m103 — attended both sessions (100%)
    //   m302 — attended session 1 only, missed session 2 (50%)
    //   m304 — missed session 1, attended session 2 (50%)
    return [
      const SessionAttendance(sessionId: 'session2_1', memberId: 'm101', present: true),
      const SessionAttendance(sessionId: 'session2_2', memberId: 'm101', present: true),
      const SessionAttendance(sessionId: 'session2_1', memberId: 'm103', present: true),
      const SessionAttendance(sessionId: 'session2_2', memberId: 'm103', present: true),
      const SessionAttendance(sessionId: 'session2_1', memberId: 'm302', present: true),
      const SessionAttendance(sessionId: 'session2_2', memberId: 'm302', present: false),
      const SessionAttendance(sessionId: 'session2_1', memberId: 'm304', present: false),
      const SessionAttendance(sessionId: 'session2_2', memberId: 'm304', present: true),
    ];
  }

  /// Marks `memberId` present/absent for `sessionId`. Replaces any
  /// existing record for that exact member+session pair.
  static void setAttendance(String sessionId, String memberId, bool present) {
    all.removeWhere((a) => a.sessionId == sessionId && a.memberId == memberId);
    all.add(SessionAttendance(sessionId: sessionId, memberId: memberId, present: present));
  }

  static bool? attendanceFor(String sessionId, String memberId) {
    try {
      return all.firstWhere((a) => a.sessionId == sessionId && a.memberId == memberId).present;
    } catch (_) {
      return null; // not yet marked
    }
  }

  static List<SessionAttendance> forSession(String sessionId) {
    return all.where((a) => a.sessionId == sessionId).toList();
  }

  /// Computes `memberId`'s attendance rate (0.0-1.0) across all of
  /// `sessionIds` — sessions with no recorded check-in for this
  /// member are treated as absent, so an incomplete roll call
  /// correctly lowers the rate rather than being silently excluded.
  static double attendanceRateFor(String memberId, List<String> sessionIds) {
    if (sessionIds.isEmpty) return 0;
    final presentCount = sessionIds.where((sid) => attendanceFor(sid, memberId) == true).length;
    return presentCount / sessionIds.length;
  }
}

class MockClassFeedback {
  static final List<ClassFeedback> all = _seedFeedback();

  static List<ClassFeedback> _seedFeedback() {
    final now = DateTime.now();
    return [
      // m103 — submitted, named (not anonymous)
      ClassFeedback(
        id: 'feedback1',
        classId: 'class2',
        memberId: 'm103',
        answers: const [
          FeedbackAnswer(questionId: 'fq1', ratingValue: 5),
          FeedbackAnswer(questionId: 'fq2', ratingValue: 4),
          FeedbackAnswer(questionId: 'fq3', textValue: 'More hands-on drills for disaster scenarios would help.'),
        ],
        submittedAt: now.subtract(const Duration(days: 25)),
      ),
      // m302 — submitted anonymously, tests the isAnonymous flag
      ClassFeedback(
        id: 'feedback2',
        classId: 'class2',
        memberId: 'm302',
        answers: const [
          FeedbackAnswer(questionId: 'fq1', ratingValue: 4),
          FeedbackAnswer(questionId: 'fq2', ratingValue: 5),
          FeedbackAnswer(questionId: 'fq3', textValue: 'Would like a refresher session closer to actual deployment dates.'),
        ],
        submittedAt: now.subtract(const Duration(days: 24)),
        isAnonymous: true,
      ),
      // m101 and m304 deliberately have NOT submitted yet — tests
      // that hasSubmitted correctly returns false for them and the
      // "Give Feedback" button still shows.
    ];
  }

  static void add(ClassFeedback feedback) {
    all.add(feedback);
  }

  static List<ClassFeedback> forClass(String classId) {
    return all.where((f) => f.classId == classId).toList();
  }

  static bool hasSubmitted(String classId, String memberId) {
    return all.any((f) => f.classId == classId && f.memberId == memberId);
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK CLOSURE REPORTS & POST-TRAINING REPORTS
// One report per class (latest save wins) — in-memory store, resets
// on app restart, replaced by Supabase in Module 16.
// ═══════════════════════════════════════════════════════════════
class MockClosureReports {
  static final List<ClassClosureReport> all = _seedReports();

  static List<ClassClosureReport> _seedReports() {
    final now = DateTime.now();
    return [
      // class2 (Disaster Management Fundamentals, completed 28 days
      // ago) — deadline already passed 14 days ago, so this report
      // shows the LOCKED state by default, demonstrating the
      // request-edit-access flow without any extra setup.
      ClassClosureReport(
        id: 'closure1',
        classId: 'class2',
        preparedByMemberId: 'm2',
        preparedAt: now.subtract(const Duration(days: 27)),
        submissionDeadline: now.subtract(const Duration(days: 14)),
        totalEnrolled: 4,
        totalCompleted: 4, // all 4 attended at least one session
        sessionAttendanceCounts: const {
          'session2_1': 3, // m101, m103, m302 present
          'session2_2': 3, // m101, m103, m304 present
        },
        memberAttendanceRates: const {
          'm101': 1.0,
          'm103': 1.0,
          'm302': 0.5,
          'm304': 0.5,
        },
        totalAllocated: 0,
        totalSpent: 0,
        skillsAwardedSummary: const ['Disaster Management'],
        certificatesIssuedCount: 4,
        issuesEncountered: 'Two participants missed one session each due to a scheduling clash with a duty assignment that day.',
        recommendations: 'Check the duty roster before finalizing session dates for the next run of this class.',
      ),
    ];
  }

  static void save(ClassClosureReport report) {
    all.removeWhere((r) => r.classId == report.classId);
    all.add(report);
  }

  static ClassClosureReport? forClass(String classId) {
    try {
      return all.firstWhere((r) => r.classId == classId);
    } catch (_) {
      return null;
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK CLOSURE REPORT EDIT REQUESTS
// Post-deadline unlock requests for the Closure Report — always
// routed to Master Access. In-memory store, resets on app restart,
// replaced by Supabase in Module 16.
// ═══════════════════════════════════════════════════════════════
class MockClosureReportEditRequests {
  static final List<ClosureReportEditRequest> all = _seedRequests();

  static List<ClosureReportEditRequest> _seedRequests() {
    final now = DateTime.now();
    return [
      // m2 requesting to fix the Issues/Recommendations text on
      // class2's now-locked closure report (closure1) — tests the
      // Master Access review screen and the per-section approval.
      ClosureReportEditRequest(
        id: 'editreq1',
        classId: 'class2',
        closureReportId: 'closure1',
        requesterId: 'm2',
        sectionsRequested: const [
          ClosureReportSection.issuesEncountered,
          ClosureReportSection.recommendations,
        ],
        reason: 'Need to correct the recommendation wording before this goes to the Brigade Office quarterly summary.',
        status: ClosureReportEditRequestStatus.pending,
        requestedAt: now.subtract(const Duration(days: 1)),
      ),
    ];
  }

  static void add(ClosureReportEditRequest request) {
    all.add(request);
  }

  static void update(ClosureReportEditRequest updated) {
    final index = all.indexWhere((r) => r.id == updated.id);
    if (index != -1) {
      all[index] = updated;
    } else {
      all.add(updated);
    }
  }

  static List<ClosureReportEditRequest> pending() {
    final result = all.where((r) => r.status == ClosureReportEditRequestStatus.pending).toList();
    result.sort((a, b) => a.requestedAt.compareTo(b.requestedAt));
    return result;
  }

  /// Currently-granted sections for `classId`'s closure report —
  /// unions every approved request's sectionsGranted, since multiple
  /// separate unlock requests could each grant different sections
  /// over time.
  static List<ClosureReportSection> grantedSectionsForClass(String classId) {
    final granted = <ClosureReportSection>{};
    for (final r in all) {
      if (r.classId == classId && r.status == ClosureReportEditRequestStatus.approved) {
        granted.addAll(r.sectionsGranted);
      }
    }
    return granted.toList();
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK OFFICER INVITE REQUESTS
// Investigation meeting officer-invite requests from the Committee
// Chairman, routed to Master Access for approval. In-memory store,
// resets on app restart, replaced by Supabase in Module 16.
// ═══════════════════════════════════════════════════════════════
class MockOfficerInviteRequests {
  static final List<OfficerInviteRequest> all = _seedRequests();

  static List<OfficerInviteRequest> _seedRequests() {
    final now = DateTime.now();
    return [
      // m2 (highest-ranking on inv1's committee, so treated as
      // Chairman) requesting to invite m101 (Company Commander,
      // already on the investigation's committee per inv1's seed
      // data, but not yet invited to meeting3 specifically) — tests
      // the Master Access approval flow directly.
      OfficerInviteRequest(
        id: 'invite1',
        meetingId: 'meeting3',
        requestedByMemberId: 'm2',
        officerMemberId: 'm101',
        reason: 'Need direct input on the accused\'s duty attendance records before the next stage.',
        status: OfficerInviteRequestStatus.pending,
        requestedAt: now.subtract(const Duration(hours: 2)),
      ),
    ];
  }

  static void add(OfficerInviteRequest request) {
    all.add(request);
  }

  static void update(OfficerInviteRequest updated) {
    final index = all.indexWhere((r) => r.id == updated.id);
    if (index != -1) {
      all[index] = updated;
    } else {
      all.add(updated);
    }
  }

  static List<OfficerInviteRequest> pendingForMeeting(String meetingId) {
    return all
        .where((r) => r.meetingId == meetingId && r.status == OfficerInviteRequestStatus.pending)
        .toList();
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK CLASS NOMINATION LISTS
// In-memory store, resets on app restart, replaced by Supabase in
// Module 16.
// ═══════════════════════════════════════════════════════════════
class MockNominationLists {
  static final List<ClassNominationList> all = _seedNominationLists();

  static List<ClassNominationList> _seedNominationLists() {
    final now = DateTime.now();
    return [
      // Linked to meeting2's "First Aid Level 3" decision (agenda2_3
      // / dec4) — Company 1 nominating 3 members for a class that
      // doesn't exist yet. Submitted well before its deadline, so
      // creating a new class titled EXACTLY "First Aid Level 3"
      // should auto-enroll m103, m104, and m107.
      ClassNominationList(
        id: 'nom1',
        linkedMeetingId: 'meeting2',
        linkedAgendaItemId: 'agenda2_3',
        plannedClassTitle: 'First Aid Level 3',
        companyNo: 1,
        nominatedMemberIds: const ['m103', 'm104', 'm107'],
        submittedByMemberId: 'm101',
        submittedAt: now.subtract(const Duration(days: 5)),
        submissionDeadline: now.add(const Duration(days: 9)),
        status: NominationListStatus.pending,
      ),
    ];
  }

  static void add(ClassNominationList list) {
    all.add(list);
  }

  static void update(ClassNominationList updated) {
    final index = all.indexWhere((l) => l.id == updated.id);
    if (index != -1) {
      all[index] = updated;
    } else {
      all.add(updated);
    }
  }

  static List<ClassNominationList> pendingForCompany(int companyNo) {
    return all
        .where((l) => l.companyNo == companyNo && l.status == NominationListStatus.pending)
        .toList();
  }

  /// All pending lists matching `classTitle` exactly, regardless of
  /// company — a new class can fulfill nomination lists from
  /// multiple companies at once if several submitted lists for the
  /// same planned class title.
  static List<ClassNominationList> matching(String classTitle) {
    final normalized = classTitle.trim().toLowerCase();
    return all
        .where((l) =>
            l.status == NominationListStatus.pending &&
            l.plannedClassTitle.trim().toLowerCase() == normalized)
        .toList();
  }

  /// Called when a new TrainingClass is created. Finds any pending,
  /// on-time nomination lists matching the class's title, marks them
  /// fulfilled, and returns the union of all their nominated member
  /// IDs — still subject to the caller applying normal eligibility
  /// checks (required skills, certificate-already-held, max
  /// participants) before actually enrolling anyone.
  static List<String> resolveNominationsForNewClass(String classId, String classTitle) {
    final candidates = matching(classTitle).where((l) => l.wasSubmittedOnTime).toList();
    final nominatedIds = <String>{};

    for (final list in candidates) {
      nominatedIds.addAll(list.nominatedMemberIds);
      update(ClassNominationList(
        id: list.id, linkedMeetingId: list.linkedMeetingId,
        linkedAgendaItemId: list.linkedAgendaItemId, plannedClassTitle: list.plannedClassTitle,
        companyNo: list.companyNo, nominatedMemberIds: list.nominatedMemberIds,
        submittedByMemberId: list.submittedByMemberId, submittedAt: list.submittedAt,
        submissionDeadline: list.submissionDeadline,
        status: NominationListStatus.fulfilled, fulfilledByClassId: classId,
      ));
    }

    return nominatedIds.toList();
  }
}

class MockPostTrainingReports {
  static final List<PostTrainingReport> all = _seedReports();

  static List<PostTrainingReport> _seedReports() {
    final now = DateTime.now();
    return [
      // Wraps closure1 (class2) — prepared but NOT yet approved,
      // tests the Approve Report button for Master Access/Brigade
      // Office Chief.
      PostTrainingReport(
        id: 'pt1',
        classId: 'class2',
        closureReportId: 'closure1',
        preparedByMemberId: 'm2',
        preparedAt: now.subtract(const Duration(days: 20)),
        impactAssessment: 'Strengthens the brigade\'s disaster response coordination ahead of monsoon season — all 4 participants can now support DANA assessments in the field.',
        skillVerificationByMemberId: const {
          'm101': true,
          'm103': true,
          'm302': false, // attended only 50% of sessions — not yet verified
          'm304': false,
        },
        futurePlanning: 'Recommend a follow-up advanced module once the basic cohort has 3+ months of field experience.',
      ),
    ];
  }

  static void save(PostTrainingReport report) {
    all.removeWhere((r) => r.classId == report.classId);
    all.add(report);
  }

  static PostTrainingReport? forClass(String classId) {
    try {
      return all.firstWhere((r) => r.classId == classId);
    } catch (_) {
      return null;
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK CERTIFICATES — empty until real data entered via the app
// ═══════════════════════════════════════════════════════════════
class MockCertificates {
  static final List<Certificate> all = _seedCertificates();

  static List<Certificate> _seedCertificates() {
    final now = DateTime.now();
    return [
      // m102 already holds the certificate that class1 (First Aid
      // Level 2 Refresher) would award, and is NOT currently
      // enrolled — demonstrates "Request to Join" correctly hiding
      // for someone who already has the matching certificate.
      Certificate(
        id: 'cert1',
        memberId: 'm102',
        title: 'First Aid Level 2 Refresher',
        titleMm: 'အသက်ဆယ်ယူ အဆင့် ၂ ပြန်လည်လေ့ကျင့်ခြင်း',
        certType: 'First Aid Level 2 Refresher',
        issuedDate: now.subtract(const Duration(days: 200)),
        issuedById: 'm101',
        referenceNo: 'CERT-2025-0042',
      ),
    ];
  }

  static List<Certificate> forMember(String memberId) {
    return all.where((c) => c.memberId == memberId).toList();
  }

  /// Does `memberId` already hold a certificate whose certType or
  /// title matches `classTitle`? Used to hide "Request to Join" for
  /// a class whose certificate the member already has — e.g. they
  /// completed this same class (or an equivalent one) before.
  /// Matches on either certType or title since there's no direct
  /// class-to-certificate-type link in the data model.
  static bool hasCertificateMatching(String memberId, String classTitle) {
    final normalizedTitle = classTitle.trim().toLowerCase();
    return forMember(memberId).any((c) =>
        c.certType.trim().toLowerCase() == normalizedTitle ||
        c.title.trim().toLowerCase() == normalizedTitle);
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK TRANSFER HISTORY — empty until real data entered via the app
// ═══════════════════════════════════════════════════════════════
class MockTransferHistory {
  static final List<TransferHistory> all = _seedHistory();

  static List<TransferHistory> _seedHistory() {
    final now = DateTime.now();
    return [
      TransferHistory(
        id: 'transfer1',
        memberId: 'm106',
        type: TransferType.promotion,
        fromRankOrUnit: 'Platoon Sergeant',
        toRankOrUnit: 'Company Sergeant Major',
        date: now.subtract(const Duration(days: 400)),
        authorizedById: 'm101',
        reason: 'Demonstrated strong leadership during the 2025 flood response deployment.',
      ),
      // Linked to punish2 (the active suspension on m119) — shows
      // the punishmentId connection between disciplinary action and
      // a resulting transfer/demotion.
      TransferHistory(
        id: 'transfer2',
        memberId: 'm119',
        type: TransferType.demotion,
        fromRankOrUnit: 'Section Leader',
        toRankOrUnit: 'Private',
        date: now.subtract(const Duration(days: 8)),
        authorizedById: 'm2',
        reason: 'Disciplinary action pending conduct review outcome.',
        punishmentId: 'punish2',
      ),
    ];
  }

  static List<TransferHistory> forMember(String memberId) {
    final result = all.where((t) => t.memberId == memberId).toList();
    result.sort((a, b) => b.date.compareTo(a.date));
    return result;
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK EQUIPMENT — empty until real data entered via the app
// ═══════════════════════════════════════════════════════════════
class MockEquipment {
  static final List<Equipment> all = [
    Equipment(id: 'eq1', name: 'First Aid Kit (Standard)', nameMm: 'အသက်ဆယ်ယူပစ္စည်းအိတ် (သာမန်)', category: 'Medical', totalQuantity: 20, availableQuantity: 14, condition: 'Good', storageLocation: 'Brigade Office Store Room A'),
    Equipment(id: 'eq2', name: 'Stretcher', nameMm: 'လေငွေ့ထမ်းစင်', category: 'Medical', totalQuantity: 6, availableQuantity: 5, condition: 'Good', storageLocation: 'Brigade Office Store Room A'),
    Equipment(id: 'eq3', name: 'Megaphone', nameMm: 'အသံချဲ့စက်', category: 'Communication', totalQuantity: 8, availableQuantity: 6, condition: 'Good', storageLocation: 'Brigade Office Store Room B'),
    Equipment(id: 'eq4', name: 'Walkie-Talkie Set', nameMm: 'ဝေါ်ကီတေါ်ကီ', category: 'Communication', totalQuantity: 12, availableQuantity: 9, condition: 'Fair', storageLocation: 'Brigade Office Store Room B'),
    Equipment(id: 'eq5', name: 'Barricade Tape Roll', nameMm: 'အတားအဆီးကြိုးလိပ်', category: 'Safety', totalQuantity: 30, availableQuantity: 22, condition: 'Good', storageLocation: 'Brigade Office Store Room C'),
    Equipment(id: 'eq6', name: 'Reflective Vest', nameMm: 'အလင်းပြန်အင်္ကျီ', category: 'Safety', totalQuantity: 40, availableQuantity: 35, condition: 'Good', storageLocation: 'Brigade Office Store Room C'),
  ];
}

// ═══════════════════════════════════════════════════════════════
// MODULE 7 ADDITIONS — MockEvents
//
// Seeded with one realistic large-scale event (charity marathon
// along Strand Road, Botahtaung) linked to duty7 above. Positions
// use real-world coordinates around the Botahtaung/Strand Road area
// of Yangon so the map renders a believable route layout.
// ═══════════════════════════════════════════════════════════════
class MockEvents {
  static final List<Event> all = _seedEvents();

  static List<Event> _seedEvents() {
    final now = DateTime.now();
    DateTime d(int dayOffset) =>
        DateTime(now.year, now.month, now.day + dayOffset);

    return [
      Event(
        id: 'event1',
        dutyId: 'duty7',
        title: 'Botahtaung Charity Marathon — Medical Coverage',
        titleMm: 'ဗိုလ်တထောင် မဟာမိတ် မာရသွန် — ကျန်းမာရေးထောက်ပံ့မှု',
        date: d(14),
        startHour: 5, startMinute: 0,
        endHour: 11, endMinute: 0,
        location: 'Botahtaung Township — Strand Road Route',
        latitude: 16.7733, longitude: 96.1689, // Botahtaung jetty area
        description: 'Medical and safety coverage along the marathon route, with aid stations and a command post.',
        status: EventStatus.planning,
        positions: [
          EventPosition(
            id: 'pos1',
            eventId: 'event1',
            nameEn: 'Command Post — Botahtaung Jetty',
            type: EventPositionType.command,
            locationDescription: 'Start/finish line, Botahtaung Jetty',
            latitude: 16.7733, longitude: 96.1689,
            requiredMembers: 2,
            assignedMemberIds: const ['m1'],
            requiredSkillIds: const ['sk5'], // Leadership
            equipmentIds: const ['eq3', 'eq4'], // Megaphone, Walkie-talkie
          ),
          EventPosition(
            id: 'pos2',
            eventId: 'event1',
            nameEn: 'Aid Station 1 — Strand Road Junction',
            type: EventPositionType.point,
            locationDescription: 'Strand Road & Lower Pazundaung Street junction',
            latitude: 16.7708, longitude: 96.1652,
            requiredMembers: 3,
            assignedMemberIds: const ['m101'],
            requiredSkillIds: const ['sk1'], // First Aid Level 1
            equipmentIds: const ['eq1', 'eq2'], // First aid kit, Stretcher
          ),
          EventPosition(
            id: 'pos3',
            eventId: 'event1',
            nameEn: 'Aid Station 2 — Pansodan Junction',
            type: EventPositionType.point,
            locationDescription: 'Strand Road & Pansodan Street junction',
            latitude: 16.7726, longitude: 96.1583,
            requiredMembers: 3,
            assignedMemberIds: const [],
            requiredSkillIds: const ['sk1'],
            equipmentIds: const ['eq1', 'eq2'],
          ),
          EventPosition(
            id: 'pos4',
            eventId: 'event1',
            nameEn: 'Mobile Patrol — Route Midpoint',
            type: EventPositionType.patrol,
            locationDescription: 'Patrolling Strand Road between aid stations',
            latitude: 16.7717, longitude: 96.1618,
            requiredMembers: 2,
            assignedMemberIds: const ['m120'],
            requiredSkillIds: const ['sk1'],
            equipmentIds: const ['eq4', 'eq6'], // Walkie-talkie, Vest
            // Patrols only this stretch — Aid Station 1 to the
            // midpoint — NOT the full marathon route, demonstrating
            // that a patrol's path doesn't have to cover everything.
            patrolPath: const [
              RouteWaypoint(latitude: 16.7708, longitude: 96.1652, label: 'Aid Station 1'),
              RouteWaypoint(latitude: 16.7717, longitude: 96.1618, label: 'Midpoint'),
            ],
          ),
          EventPosition(
            id: 'pos5',
            eventId: 'event1',
            nameEn: 'Standby — Reserve Team',
            type: EventPositionType.standby,
            locationDescription: 'Brigade Office, on call for overflow',
            latitude: 16.7745, longitude: 96.1701,
            requiredMembers: 2,
            assignedMemberIds: const [],
            requiredSkillIds: const [],
            equipmentIds: const ['eq1'],
          ),
        ],
        routes: [
          EventRoute(
            id: 'route1',
            eventId: 'event1',
            name: 'Main Route — Strand Road Out-and-Back',
            colorHex: '#1D9E75', // teal
            waypoints: const [
              RouteWaypoint(latitude: 16.7733, longitude: 96.1689, label: 'Start — Botahtaung Jetty'),
              RouteWaypoint(latitude: 16.7720, longitude: 96.1665),
              RouteWaypoint(latitude: 16.7708, longitude: 96.1652, label: 'Aid Station 1 — Strand Rd Junction'),
              RouteWaypoint(latitude: 16.7717, longitude: 96.1618, label: 'Midpoint — Patrol Zone'),
              RouteWaypoint(latitude: 16.7726, longitude: 96.1583, label: 'Aid Station 2 — Pansodan Junction'),
              RouteWaypoint(latitude: 16.7717, longitude: 96.1618),
              RouteWaypoint(latitude: 16.7708, longitude: 96.1652),
              RouteWaypoint(latitude: 16.7720, longitude: 96.1665),
              RouteWaypoint(latitude: 16.7733, longitude: 96.1689, label: 'Finish — Botahtaung Jetty'),
            ],
          ),
        ],
      ),
    ];
  }

  static Event? findById(String id) {
    try {
      return all.firstWhere((e) => e.id == id);
    } catch (_) {
      return null;
    }
  }

  /// Adds a newly created event to the in-memory list. Replaced by a
  /// real Supabase insert in Module 16.
  static void add(Event event) {
    all.add(event);
  }

  /// Replaces an existing event by id (e.g. after setting the venue
  /// location, or adding/editing positions and routes).
  static void update(Event updated) {
    final index = all.indexWhere((e) => e.id == updated.id);
    if (index != -1) {
      all[index] = updated;
    } else {
      all.add(updated);
    }
  }

  static Event? findByDutyId(String dutyId) {
    try {
      return all.firstWhere((e) => e.dutyId == dutyId);
    } catch (_) {
      return null;
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK FUND ENTRIES — empty until real data entered via the app
// ═══════════════════════════════════════════════════════════════
class MockFundEntries {
  static final List<FundEntry> all = _seedEntries();

  static List<FundEntry> _seedEntries() {
    final now = DateTime.now();
    return [
      FundEntry(
        id: 'fund1',
        type: 'income',
        description: 'Quarterly brigade fund allocation from Myanmar Red Cross Society HQ',
        amount: 500000,
        date: now.subtract(const Duration(days: 60)),
        category: 'HQ Allocation',
        recordedById: 'm3',
        approvedById: 'm1',
        needsApproval: false,
      ),
      FundEntry(
        id: 'fund2',
        type: 'expense',
        description: 'First Aid Level 2 Refresher — materials and instructor honorarium',
        amount: 35000,
        date: now.subtract(const Duration(days: 2)),
        category: 'Training',
        recordedById: 'm106',
        approvedById: 'm101',
        needsApproval: false,
        classId: 'class1',
        referenceNo: 'FE-2026-014',
      ),
      FundEntry(
        id: 'fund3',
        type: 'expense',
        description: 'Charity marathon first aid station supplies',
        amount: 80000,
        date: now.subtract(const Duration(days: 10)),
        category: 'Event Support',
        recordedById: 'm6',
        needsApproval: true, // pending approval — approvedById intentionally null
        referenceNo: 'FE-2026-015',
      ),
    ];
  }

  static double get balance =>
      all.fold(0.0, (sum, e) => e.type == 'income' ? sum + e.amount : sum - e.amount);
}

// ═══════════════════════════════════════════════════════════════
// MOCK LIBRARY DOCUMENTS — empty until real data entered via the app
// ═══════════════════════════════════════════════════════════════
class MockLibrary {
  static final List<LibraryDocument> all = _seedDocuments();

  static List<LibraryDocument> _seedDocuments() {
    final now = DateTime.now();
    return [
      LibraryDocument(
        id: 'doc1',
        title: 'Myanmar Red Cross Society — Brigade Operations Manual',
        titleMm: 'မြန်မာနိုင်ငံ ကြက်ခြေနီအသင်း — တပ်ဖွဲ့လုပ်ငန်းလမ်းညွှန်',
        category: 'Operations',
        fileUrl: 'library/brigade_operations_manual.pdf',
        fileType: 'pdf',
        uploadedDate: now.subtract(const Duration(days: 300)),
        uploadedById: 'm3',
        isPublic: true,
      ),
      LibraryDocument(
        id: 'doc2',
        title: 'First Aid Level 2 — Course Materials',
        titleMm: 'အသက်ဆယ်ယူ အဆင့် ၂ — သင်တန်းအထောက်အထား',
        category: 'Training',
        fileUrl: 'library/first_aid_level_2_materials.pdf',
        fileType: 'pdf',
        uploadedDate: now.subtract(const Duration(days: 6)),
        uploadedById: 'm106',
        classId: 'class1',
        isPublic: false, // only visible to enrolled members
      ),
    ];
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK ACCESS GRANT REQUESTS
// In-memory store for the section-level access grant system —
// resets on app restart, replaced by Supabase in Module 16.
// ═══════════════════════════════════════════════════════════════
class MockAccessGrants {
  static final List<AccessGrantRequest> all = _seedGrants();

  static List<AccessGrantRequest> _seedGrants() {
    final now = DateTime.now();
    return [
      // m106 (Company Sergeant Major, C1) requesting access to
      // m101's (Company Commander) Contact Info — pending, tests the
      // approval screen directly.
      AccessGrantRequest(
        id: 'grant1',
        requesterId: 'm106',
        targetMemberId: 'm101',
        requestedSections: const [ProfileSection.contactInfo],
        reason: 'Need to reach the Commander directly during the upcoming marathon event for last-minute logistics coordination.',
        status: AccessGrantStatus.pending,
        requestedAt: now.subtract(const Duration(hours: 6)),
      ),
      // m106 already approved for Platoon Leader (m103) detail —
      // tests the granted-section chip display on the profile screen.
      AccessGrantRequest(
        id: 'grant2',
        requesterId: 'm106',
        targetMemberId: 'm103',
        requestedSections: const [ProfileSection.membershipHistory],
        reason: 'Reviewing service history while preparing the quarterly readiness report.',
        status: AccessGrantStatus.approved,
        approverId: 'm101',
        requestedAt: now.subtract(const Duration(days: 5)),
        decidedAt: now.subtract(const Duration(days: 4)),
        expiresAt: now.add(const Duration(days: 25)),
      ),
    ];
  }

  static void add(AccessGrantRequest request) {
    all.add(request);
  }

  static void update(AccessGrantRequest updated) {
    final index = all.indexWhere((r) => r.id == updated.id);
    if (index != -1) {
      all[index] = updated;
    } else {
      all.add(updated);
    }
  }

  /// Active (approved, not expired) grants between this exact
  /// requester/target pair — what canViewGrantedSection checks against.
  static List<AccessGrantRequest> activeFor(String requesterId, String targetId) {
    return all
        .where((r) =>
            r.requesterId == requesterId &&
            r.targetMemberId == targetId &&
            r.isActive)
        .toList();
  }

  /// Pending requests awaiting decision, scoped to `approverCompanyNo`
  /// — for the Company Commander/Deputy's own inbox of requests to
  /// review (only requests targeting someone in their own company).
  static List<AccessGrantRequest> pendingFor(int? approverCompanyNo) {
    return all.where((r) {
      if (r.status != AccessGrantStatus.pending) return false;
      final target = MockMembers.findById(r.targetMemberId);
      return target != null && target.companyNo == approverCompanyNo;
    }).toList();
  }

  /// All requests submitted by `requesterId`, most recent first —
  /// for the Sergeant Major's own "my requests" view.
  static List<AccessGrantRequest> submittedBy(String requesterId) {
    final result = all.where((r) => r.requesterId == requesterId).toList();
    result.sort((a, b) => b.requestedAt.compareTo(a.requestedAt));
    return result;
  }
}

// ═══════════════════════════════════════════════════════════════
// MOCK FEATURE ACCESS REQUESTS
// Generic, module/feature-level access requests — separate from
// MockAccessGrants (which is the Member-profile-specific system).
// In-memory store, resets on app restart, replaced by Supabase in
// Module 16.
// ═══════════════════════════════════════════════════════════════
class MockFeatureAccessRequests {
  static final List<FeatureAccessRequest> all = _seedRequests();

  static List<FeatureAccessRequest> _seedRequests() {
    final now = DateTime.now();
    return [
      // m103 (Platoon Leader) requesting Fund Ledger access — tests
      // the Master Access review queue.
      FeatureAccessRequest(
        id: 'feat1',
        requesterId: 'm103',
        moduleOrFeature: 'Fund Ledger',
        reason: 'Need to verify the training budget figures before the next platoon briefing.',
        status: FeatureAccessStatus.pending,
        requestedAt: now.subtract(const Duration(hours: 14)),
      ),
      // m118 already approved for Archive access — tests the
      // approved-state display in the requester's own list.
      FeatureAccessRequest(
        id: 'feat2',
        requesterId: 'm118',
        moduleOrFeature: 'Archive',
        reason: 'Researching past charity marathon planning documents for this year\'s event.',
        status: FeatureAccessStatus.approved,
        approverId: 'm1',
        requestedAt: now.subtract(const Duration(days: 10)),
        decidedAt: now.subtract(const Duration(days: 9)),
        expiresAt: now.add(const Duration(days: 20)),
      ),
    ];
  }

  static void add(FeatureAccessRequest request) {
    all.add(request);
  }

  static void update(FeatureAccessRequest updated) {
    final index = all.indexWhere((r) => r.id == updated.id);
    if (index != -1) {
      all[index] = updated;
    } else {
      all.add(updated);
    }
  }

  /// All pending requests — Master Access reviews these regardless
  /// of which company/unit the requester belongs to, since approval
  /// is always at the top tier for this generic system.
  static List<FeatureAccessRequest> pending() {
    final result = all.where((r) => r.status == FeatureAccessStatus.pending).toList();
    result.sort((a, b) => a.requestedAt.compareTo(b.requestedAt)); // oldest first
    return result;
  }

  /// Full history (all statuses), most recent first.
  static List<FeatureAccessRequest> history() {
    final result = List<FeatureAccessRequest>.from(all);
    result.sort((a, b) => b.requestedAt.compareTo(a.requestedAt));
    return result;
  }

  /// Requests submitted by `requesterId`, most recent first.
  static List<FeatureAccessRequest> submittedBy(String requesterId) {
    final result = all.where((r) => r.requesterId == requesterId).toList();
    result.sort((a, b) => b.requestedAt.compareTo(a.requestedAt));
    return result;
  }

  /// Is there an active (approved, not expired) grant for
  /// `requesterId` on `moduleOrFeature`? Exact string match on the
  /// feature name — useful once a specific screen wants to check
  /// "has this person been granted access to me specifically."
  static bool hasActiveAccess(String requesterId, String moduleOrFeature) {
    return all.any((r) =>
        r.requesterId == requesterId &&
        r.moduleOrFeature == moduleOrFeature &&
        r.isActive);
  }
}
