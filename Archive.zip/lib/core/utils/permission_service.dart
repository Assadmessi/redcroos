import '../constants/app_constants.dart';
import '../../data/models/models.dart';

// ─────────────────────────────────────────────
// PERMISSION SERVICE
// Central place for all access control logic
// ─────────────────────────────────────────────
class PermissionService {
  PermissionService._();

  // ─── MASTER ACCESS CHECK ─────────────────
  /// Brigade Commander, Deputy, Brigade Office Chief
  /// + Chairperson all have full access
  static bool hasMasterAccess(Member member) {
    if (member.isChairperson) return true;
    if (member.rank == MemberRank.brigadeCommander) return true;
    if (member.rank == MemberRank.deputyBrigadeCommander) return true;
    if (member.isBrigadeOfficeChief) return true;
    return false;
  }

  // ─── UNIT SCOPE ──────────────────────────
  /// Determine what scope a member has access to
  static UnitScope getUnitScope(Member member) {
    // Master access — entire brigade
    if (hasMasterAccess(member)) return UnitScope.brigadWide;

    // Special brigade authority granted by Brigade Commander
    if (member.hasBrigadeOfficeAuthority) return UnitScope.brigadWide;

    // Any rank assigned to Brigade Office — brigade wide
    if (member.unitType == UnitType.brigadeOffice) return UnitScope.brigadWide;

    // Company Office members — company wide
    if (member.unitType == UnitType.companyOffice) return UnitScope.companyWide;

    // Platoon Office members — platoon wide
    if (member.unitType == UnitType.platoonOffice) return UnitScope.platoonWide;

    // Field assignments by rank
    // (brigadeCommander/deputyBrigadeCommander/brigadeOffice cases are
    // already handled above via hasMasterAccess() and unitType checks —
    // if we reach here for those ranks, treat as field fallback below)
    switch (member.rank) {
      case MemberRank.brigadeCommander:
      case MemberRank.deputyBrigadeCommander:
        return UnitScope.brigadWide;

      case MemberRank.companyCommander:
      case MemberRank.deputyCompanyCommander:
      case MemberRank.companySergeantMajor:
        return UnitScope.companyWide;

      case MemberRank.platoonLeader:
      case MemberRank.platoonSergeant:
        return UnitScope.platoonWide;

      case MemberRank.warrantOfficer:
      case MemberRank.sergeantClerk:
        // These are only brigade-wide if in Brigade Office
        // (already handled above) — if we reach here they are field
        return UnitScope.platoonWide;

      case MemberRank.sectionLeader:
      case MemberRank.deputySectionLeader:
        return UnitScope.sectionWide;

      case MemberRank.private:
        return UnitScope.ownOnly;
    }
  }

  // ─── MEMBER VISIBILITY ───────────────────
  static bool canViewMember(Member viewer, Member target) {
    if (hasMasterAccess(viewer)) return true;
    if (viewer.id == target.id) return true;

    final scope = getUnitScope(viewer);
    switch (scope) {
      case UnitScope.brigadWide:
        return true;
      case UnitScope.companyWide:
        return target.companyNo == viewer.companyNo;
      case UnitScope.platoonWide:
        return target.companyNo == viewer.companyNo &&
            target.platoonNo == viewer.platoonNo;
      case UnitScope.sectionWide:
        return target.companyNo == viewer.companyNo &&
            target.platoonNo == viewer.platoonNo &&
            target.sectionNo == viewer.sectionNo;
      case UnitScope.ownOnly:
        return target.id == viewer.id;
    }
  }

  // ─── MEMBER MANAGEMENT ───────────────────
  static bool canManageMember(Member viewer, Member target) {
    if (target.rank == MemberRank.private &&
        viewer.rank == MemberRank.private) return false;
    if (!RankHelper.isHigherThan(viewer.rank, target.rank) &&
        viewer.id != target.id) return false;

    // Platoon Leader can VIEW full detail across their whole company
    // (via canViewFullDetail), but may only EDIT members within their
    // own platoon — not other platoons in the same company.
    if (viewer.rank == MemberRank.platoonLeader &&
        target.platoonNo != viewer.platoonNo) {
      return false;
    }

    return canViewMember(viewer, target);
  }

  // ─── DUTY ASSIGNMENT ─────────────────────
  static bool canAssignDuty(Member member) {
    if (hasMasterAccess(member)) return true;
    if (member.unitType == UnitType.brigadeOffice) return true;
    if (member.unitType == UnitType.companyOffice) return true;
    if (member.unitType == UnitType.platoonOffice) return true;
    return RankHelper.isOfficerRank(member.rank) ||
        member.rank == MemberRank.companySergeantMajor ||
        member.rank == MemberRank.platoonSergeant ||
        member.rank == MemberRank.sectionLeader ||
        member.rank == MemberRank.deputySectionLeader;
  }

  // ─── APPROVE REPORTS ─────────────────────
  static bool canApproveReport(Member approver, Member reportSubmitter) {
    if (hasMasterAccess(approver)) return true;
    if (approver.unitType == UnitType.brigadeOffice) return true;
    if (!RankHelper.isHigherThan(approver.rank, reportSubmitter.rank)) {
      return false;
    }
    return canViewMember(approver, reportSubmitter);
  }

  // ─── GENERATE REPORTS ────────────────────
  static bool canGenerateReports(Member member) {
    if (hasMasterAccess(member)) return true;
    return member.unitType == UnitType.brigadeOffice;
  }

  // ─── VIEW PUBLISHED REPORTS ──────────────
  static bool canViewPublishedReports(Member member) => true; // All members

  // ─── VIEW DRAFT REPORTS ──────────────────
  static bool canViewDraftReports(Member member) {
    if (hasMasterAccess(member)) return true;
    if (member.unitType == UnitType.brigadeOffice) return true;
    return RankHelper.isOfficerRank(member.rank);
  }

  // ─── INVESTIGATIONS ──────────────────────
  static bool canViewInvestigation(
    Member viewer,
    Investigation investigation,
  ) {
    // Recusal — accused or witness locked out regardless of rank
    if (investigation.accusedMemberIds.contains(viewer.id)) return false;
    if (investigation.witnessMemberIds.contains(viewer.id)) return false;

    // Master access
    if (hasMasterAccess(viewer)) return true;

    // Brigade Office Chief
    if (viewer.isBrigadeOfficeChief) return true;

    // Committee members — only while ongoing
    if (investigation.committeeMemberIds.contains(viewer.id)) {
      final isOngoing = investigation.status != InvestigationStatus.closed &&
          investigation.status != InvestigationStatus.concluded &&
          investigation.status != InvestigationStatus.appealConcluded;
      if (isOngoing) return true;

      // Grace period — 1 week after concluded
      if (investigation.concludedDate != null) {
        final daysSince =
            DateTime.now().difference(investigation.concludedDate!).inDays;
        if (daysSince <= 7) return true;
      }
    }

    // Appeal committee — while appeal ongoing
    if (investigation.appealCommitteeMemberIds.contains(viewer.id)) {
      final isAppealing =
          investigation.status == InvestigationStatus.appealed ||
          investigation.status == InvestigationStatus.appealReview;
      if (isAppealing) return true;
    }

    return false;
  }

  static bool canManageInvestigation(
    Member viewer,
    Investigation investigation,
  ) {
    // Recusal
    if (investigation.accusedMemberIds.contains(viewer.id)) return false;
    if (investigation.witnessMemberIds.contains(viewer.id)) return false;

    // Master access
    if (hasMasterAccess(viewer)) return true;

    // Committee members — only while ongoing and not related
    if (investigation.committeeMemberIds.contains(viewer.id)) {
      final isOngoing = investigation.status != InvestigationStatus.closed &&
          investigation.status != InvestigationStatus.concluded;
      return isOngoing;
    }

    return false;
  }

  static bool canViewSealedAttachment(
    Member viewer,
    Investigation investigation,
  ) {
    // Recusal first
    if (investigation.accusedMemberIds.contains(viewer.id)) return false;
    if (investigation.witnessMemberIds.contains(viewer.id)) return false;

    // Master access — no approval needed
    if (viewer.rank == MemberRank.brigadeCommander) return true;
    if (viewer.rank == MemberRank.deputyBrigadeCommander) return true;
    if (viewer.isChairperson) return true;

    // Others need explicit approval — checked via approvedSealedViewers list
    return investigation.approvedSealedViewers.contains(viewer.id);
  }

  // ─── PUNISHMENTS ─────────────────────────
  static bool canViewPunishment(
    Member viewer,
    Punishment punishment,
    Investigation? relatedInvestigation,
  ) {
    // Punished member sees own record always
    if (viewer.id == punishment.memberId) return true;

    // Master access
    if (hasMasterAccess(viewer)) return true;

    // Brigade Office members
    if (viewer.unitType == UnitType.brigadeOffice) return true;

    // Investigation committee — 1 week grace after concluded
    if (relatedInvestigation != null) {
      if (relatedInvestigation.committeeMemberIds.contains(viewer.id)) {
        if (relatedInvestigation.concludedDate != null) {
          final daysSince = DateTime.now()
              .difference(relatedInvestigation.concludedDate!)
              .inDays;
          if (daysSince <= 7) return true;
        }
      }
    }

    // Higher rank same company rule
    // Get punished member to check company
    // Higher rank can view lower rank in same company
    return false; // Resolved at runtime with punished member data
  }

  static bool canViewPunishmentWithTarget(
    Member viewer,
    Punishment punishment,
    Member punishedMember,
    Investigation? relatedInvestigation,
  ) {
    if (viewer.id == punishment.memberId) return true;
    if (hasMasterAccess(viewer)) return true;
    if (viewer.unitType == UnitType.brigadeOffice) return true;

    // Committee grace period
    if (relatedInvestigation != null &&
        relatedInvestigation.committeeMemberIds.contains(viewer.id)) {
      if (relatedInvestigation.concludedDate != null) {
        final days = DateTime.now()
            .difference(relatedInvestigation.concludedDate!)
            .inDays;
        if (days <= 7) return true;
      }
    }

    // Higher rank same company
    if (viewer.companyNo == punishedMember.companyNo &&
        RankHelper.isHigherThan(viewer.rank, punishedMember.rank)) {
      return true;
    }

    return false;
  }

  // ─── BLOOD DONATIONS ─────────────────────
  static bool canViewBloodDonors(Member member) {
    if (hasMasterAccess(member)) return true;
    if (member.unitType == UnitType.brigadeOffice) return true;
    if (RankHelper.isOfficerRank(member.rank)) return true;
    if (member.youthGroupRole != null &&
        member.youthGroup == YouthGroup.bloodDonations) return true;
    return false;
  }

  static bool canEditBloodDonors(Member member) {
    return member.youthGroup == YouthGroup.bloodDonations &&
        member.youthGroupRole != null;
  }

  static bool canTriggerEmergencySearch(Member member) {
    if (hasMasterAccess(member)) return true;
    if (member.unitType == UnitType.brigadeOffice) return true;
    if (RankHelper.isOfficerRank(member.rank)) return true;
    if (member.youthGroup == YouthGroup.bloodDonations) return true;
    return false;
  }

  // ─── FUND LEDGER ─────────────────────────
  static bool canViewFund(Member member) {
    if (hasMasterAccess(member)) return true;
    if (member.unitType == UnitType.brigadeOffice) return true;
    return RankHelper.isOfficerRank(member.rank);
  }

  static bool canEditFundDirectly(Member member) {
    if (member.rank == MemberRank.brigadeCommander) return true;
    if (member.rank == MemberRank.deputyBrigadeCommander) return true;
    if (member.isBrigadeOfficeChief) return true;
    return false;
  }

  static bool canSubmitFundForApproval(Member member) {
    if (canEditFundDirectly(member)) return true;
    return member.unitType == UnitType.brigadeOffice;
  }

  // ─── CERTIFICATES ────────────────────────
  static bool canViewCertificate(Member viewer, Member owner) {
    if (viewer.id == owner.id) return true;
    if (hasMasterAccess(viewer)) return true;
    if (viewer.unitType == UnitType.brigadeOffice) return true;
    return canViewMember(viewer, owner) &&
        RankHelper.isHigherThan(viewer.rank, owner.rank);
  }

  // ─── ARCHIVE ─────────────────────────────
  static bool canViewArchive(Member member) {
    if (hasMasterAccess(member)) return true;
    if (member.unitType == UnitType.brigadeOffice) return true;
    if (member.rank == MemberRank.companyCommander) return true;
    if (member.rank == MemberRank.deputyCompanyCommander) return true;
    return false;
  }

  // ─── SETTINGS ────────────────────────────
  static bool canViewSettings(Member member) {
    if (hasMasterAccess(member)) return true;
    if (member.rank == MemberRank.sergeantClerk &&
        member.unitType == UnitType.brigadeOffice) return true;
    return false;
  }

  static bool canEditSettingsDirectly(Member member) {
    return hasMasterAccess(member);
  }

  static bool canEditSettingsWithApproval(Member member) {
    return member.rank == MemberRank.sergeantClerk &&
        member.unitType == UnitType.brigadeOffice;
  }

  // ─── YOUTH WING REPORTS ──────────────────
  static bool canApproveYouthReport(Member member) {
    if (member.rank == MemberRank.brigadeCommander) return true;
    if (member.rank == MemberRank.deputyBrigadeCommander) return true;
    if (member.isBrigadeOfficeChief) return true;
    return false;
  }

  static bool canViewYouthReport(
    Member viewer,
    YouthGroup group,
    bool isPublic,
  ) {
    if (isPublic) return true;
    if (hasMasterAccess(viewer)) return true;
    if (viewer.unitType == UnitType.brigadeOffice) return true;
    if (RankHelper.isOfficerRank(viewer.rank)) return true;
    if (viewer.youthGroup == group) return true;
    return false;
  }

  // ─── DISPATCH ────────────────────────────
  static bool canCreateDispatch(Member member) {
    if (hasMasterAccess(member)) return true;
    return member.unitType == UnitType.brigadeOffice;
  }

  static bool canSuggestDispatchMember(Member member) {
    return member.rank == MemberRank.companyCommander ||
        member.rank == MemberRank.deputyCompanyCommander;
  }

  static bool canConfirmDispatch(Member member) {
    return member.rank == MemberRank.brigadeCommander ||
        member.rank == MemberRank.deputyBrigadeCommander ||
        member.isBrigadeOfficeChief;
  }

  // ─── DUTY IN SPECIFIC DUTY CONTEXT ───────
  /// Within a duty, authority comes from duty role not permanent rank
  static bool canMakeDecisionInDuty(
    Member member,
    Duty duty,
  ) {
    // Check duty role first
    final dutyMember = duty.members
        .where((dm) => dm.memberId == member.id)
        .firstOrNull;
    if (dutyMember == null) return false;

    // Commander and Officer both have decision authority within their
    // own duty, regardless of scale. (Previously this only checked
    // Officer for regular-scale duties, which meant a member assigned
    // as Commander on a regular duty had LESS authority than an
    // Officer on the same duty — fixed here.)
    return dutyMember.roleInDuty == DutyRoleInDuty.commander ||
        dutyMember.roleInDuty == DutyRoleInDuty.officer;
  }

  // ═══════════════════════════════════════════════════════════
  // MODULE 6 ADDITIONS — Duties Module
  // ═══════════════════════════════════════════════════════════

  /// Can `member` create a duty? Master Access only — structural
  /// actions on duties (create/edit/cancel/delete) are restricted to
  /// Master Access, unlike duty-role authority which only governs
  /// in-duty decisions like marking complete (see canMarkDutyComplete).
  static bool canCreateDuty(Member member) => hasAdminOrMasterAccess(member);

  /// Can `member` accept/reject their own assignment on `duty`?
  /// Only the assigned member themselves, and only while the
  /// assignment is still pending a response.
  static bool canRespondToDutyAssignment(Member member, Duty duty) {
    final dutyMember =
        duty.members.where((dm) => dm.memberId == member.id).firstOrNull;
    if (dutyMember == null) return false;
    return dutyMember.status == DutyAssignmentStatus.pending;
  }

  /// Can `member` mark `duty` as complete? This is the ONE duty
  /// action that stays available to duty-role authority — either
  /// Master Access, or whoever holds commander/officer role within
  /// THIS specific duty's roster (see canMakeDecisionInDuty). A
  /// general assignment-authority member with no role in this duty
  /// cannot mark it complete — only Master Access or this duty's own
  /// commander/officer can.
  static bool canMarkDutyComplete(Member member, Duty duty) {
    if (hasAdminOrMasterAccess(member)) return true;
    return canMakeDecisionInDuty(member, duty);
  }

  /// Can `member` cancel `duty`? Master Access only.
  static bool canCancelDuty(Member member, Duty duty) =>
      hasAdminOrMasterAccess(member);

  /// Can `member` delete `duty` entirely (distinct from cancel, which
  /// keeps a cancelled record)? Master Access only.
  static bool canDeleteDuty(Member member, Duty duty) =>
      hasAdminOrMasterAccess(member);

  /// Can `member` edit `duty`'s details (time/location/description,
  /// not the roster)? Master Access only.
  static bool canEditDuty(Member member, Duty duty) {
    if (duty.status == DutyStatus.completed ||
        duty.status == DutyStatus.cancelled) {
      return false;
    }
    return hasAdminOrMasterAccess(member);
  }

  // ═══════════════════════════════════════════════════════════
  // MODULE 7 ADDITIONS — Events & Positional Duty
  // ═══════════════════════════════════════════════════════════

  /// Can `member` create/edit/delete an Event or its EventPositions
  /// (name, type, location, required members/skills/equipment)?
  /// Master Access only — same tier as Duty create/edit/cancel/delete
  /// in Module 6, since this is a structural decision about the event
  /// itself, not an in-the-moment operational one.
  static bool canManageEvent(Member member) => hasAdminOrMasterAccess(member);

  /// Can `member` assign/unassign members to a specific position
  /// within an event? Master Access OR whoever holds commander/officer
  /// role on the event's linked Duty (mirrors canMarkDutyComplete's
  /// exception in Module 6) — `hostDuty` is the Duty this event
  /// belongs to (Event.dutyId), passed in by the caller since Event
  /// doesn't hold a direct Duty reference.
  static bool canAssignToPosition(Member member, Duty hostDuty) {
    if (hasAdminOrMasterAccess(member)) return true;
    return canMakeDecisionInDuty(member, hostDuty);
  }

  // ═══════════════════════════════════════════════════════════
  // MODULE 8 ADDITIONS — Meetings Module
  // ═══════════════════════════════════════════════════════════

  /// Can `member` create a meeting at all (regardless of scope)?
  /// Master Access/Admin — any unit, any meeting type.
  /// Deputy Company Commander, Company Commander, Deputy Brigade
  /// Commander, Brigade Commander — for their own unit only (scope
  /// checked separately via canCreateMeetingForUnit, since "own unit"
  /// needs a target company/scope to compare against).
  static bool canCreateMeeting(Member member) {
    if (hasAdminOrMasterAccess(member)) return true;
    const eligibleRanks = {
      MemberRank.deputyCompanyCommander,
      MemberRank.companyCommander,
      MemberRank.deputyBrigadeCommander,
      MemberRank.brigadeCommander,
    };
    return eligibleRanks.contains(member.rank);
  }

  /// Which MeetingTypes are actually available for `member` to pick
  /// right now? Combines the existing rank-based create eligibility
  /// with conditional availability — some types only make sense to
  /// offer when the real-world situation that justifies them exists:
  ///   - Investigation: only if there's an ongoing investigation
  ///   - Committee: only if any committee currently has an active
  ///     form (investigation, class, or other special situation)
  ///   - Youth Group: only for Youth Wing LEADERSHIP specifically
  ///     (YouthGroupRole.leader), not all youth group members
  /// General/Officer/Youth Leaders/Custom have no special condition
  /// beyond the base canCreateMeeting rank rule.
  ///
  /// `hasOngoingInvestigation` and `hasActiveCommittee` are passed in
  /// by the caller (from MockInvestigations/MockCommittees) rather
  /// than looked up here directly, since permission_service.dart
  /// must not depend on mock_data.dart (mock_data.dart already
  /// depends on this file — a reverse import would be circular).
  static List<MeetingType> availableMeetingTypesFor(
    Member member, {
    required bool hasOngoingInvestigation,
    required bool hasActiveCommittee,
  }) {
    if (!canCreateMeeting(member)) return [];

    final types = <MeetingType>[
      MeetingType.general,
      MeetingType.officer,
      MeetingType.youthLeaders,
      MeetingType.custom,
    ];

    if (hasOngoingInvestigation) types.add(MeetingType.investigation);
    if (hasActiveCommittee) types.add(MeetingType.committee);
    if (member.youthGroupRole == YouthGroupRole.leader) {
      types.add(MeetingType.youthGroup);
    }

    return types;
  }

  /// Can `member` create a meeting specifically for `targetCompanyNo`
  /// (null = brigade-wide)? Master Access/Admin can create for any
  /// scope. Company Commander/Deputy can only create for their own
  /// company. Deputy Brigade Commander/Brigade Commander (Brigade
  /// Office) can create brigade-wide.
  static bool canCreateMeetingForUnit(Member member, int? targetCompanyNo) {
    if (hasAdminOrMasterAccess(member)) return true;
    if (!canCreateMeeting(member)) return false;

    if (member.unitType == UnitType.brigadeOffice) return true; // brigade-wide ok

    // Company-level officer — only their own company.
    return member.companyNo == targetCompanyNo;
  }

  /// Can `member` edit/cancel/delete `meeting`'s details? Same
  /// authority as creating it — the creator's tier, scoped to the
  /// meeting's own company if it has one.
  static bool canManageMeeting(Member member, Meeting meeting, int? meetingCompanyNo) {
    if (meeting.status == MeetingStatus.published) return false; // finalized
    return canCreateMeetingForUnit(member, meetingCompanyNo);
  }

  /// Can `member` mark attendance (present/excused/absent) for
  /// `meeting`? The meeting's organizer/recorder, or Master Access.
  static bool canMarkAttendance(Member member, Meeting meeting) {
    if (hasAdminOrMasterAccess(member)) return true;
    return member.id == meeting.organizerMemberId ||
        member.id == meeting.recorderMemberId;
  }

  /// Can `member` record discussion/decision text on `meeting`'s
  /// agenda items? Same authority as marking attendance.
  static bool canRecordDiscussion(Member member, Meeting meeting) {
    return canMarkAttendance(member, meeting);
  }

  /// Can `member` approve/sign off on `meeting`'s minutes, moving it
  /// from drafted to signed/published? Brigade Office Chief, Deputy
  /// Brigade Commander, Brigade Commander, or Master Access/Admin —
  /// the same "leadership sign-off" tier used for formal documents
  /// throughout the app.
  static bool canApproveMinutes(Member member) {
    if (hasAdminOrMasterAccess(member)) return true;
    return member.isBrigadeOfficeChief ||
        member.rank == MemberRank.deputyBrigadeCommander ||
        member.rank == MemberRank.brigadeCommander;
  }

  // ═══════════════════════════════════════════════════════════
  // MODULE 4 ADDITIONS (later) — Section-Level Access Grant System
  //
  // Lets a Company Sergeant Major request time-limited, section-
  // specific access to a profile they can't normally see in detail —
  // their own Company Commander/Deputy, or any Platoon Leader in
  // their company. Always routed to Company Commander/Deputy for
  // approval, regardless of which of the two targets is being
  // requested. The grantor picks sections + an expiry when approving.
  // ═══════════════════════════════════════════════════════════

  /// Can `requester` submit an access-grant request for `target`'s
  /// profile? Currently scoped to Company Sergeant Major requesting
  /// their own Company Commander/Deputy, or a Platoon Leader within
  /// the same company. (Extendable to other rank pairs later — kept
  /// narrow for now since that's the only case actually specified.)
  static bool canRequestAccessGrant(Member requester, Member target) {
    if (requester.rank != MemberRank.companySergeantMajor) return false;
    if (requester.companyNo != target.companyNo) return false;
    final targetIsEligible = target.rank == MemberRank.companyCommander ||
        target.rank == MemberRank.deputyCompanyCommander ||
        target.rank == MemberRank.platoonLeader;
    return targetIsEligible;
  }

  /// Who can approve/deny an access-grant request for `target`?
  /// Always the Company Commander or Deputy Company Commander of
  /// `target`'s own company — same chain whether the request is
  /// about the Commander/Deputy themselves or about a Platoon Leader.
  static bool canApproveAccessGrant(Member approver, Member target) {
    if (hasAdminOrMasterAccess(approver)) return true;
    final isCompanyLead = approver.rank == MemberRank.companyCommander ||
        approver.rank == MemberRank.deputyCompanyCommander;
    if (!isCompanyLead) return false;
    return approver.companyNo == target.companyNo;
  }

  /// Can `viewer` see `section` of `target`'s profile, given an
  /// active (approved, not expired) AccessGrantRequest? Checks the
  /// most recent matching grant for this requester/target/section
  /// combination — callers should pass in the relevant grant list
  /// (e.g. from MockAccessGrants) already filtered to this
  /// requester+target pair.
  static bool canViewGrantedSection(
    List<AccessGrantRequest> grantsForThisPair,
    ProfileSection section,
  ) {
    return grantsForThisPair.any((g) => g.grantsSection(section));
  }

  // ═══════════════════════════════════════════════════════════
  // GENERIC FEATURE ACCESS REQUEST SYSTEM
  //
  // Separate from the Member-profile-specific AccessGrantRequest
  // system above. Any office-tier member (Platoon Office, Company
  // Office, Brigade Office) can request access to a module/feature
  // they don't currently have, for their office's work. Always
  // routed to Master Access for review — see the design note on
  // FeatureAccessRequest for why this doesn't try to dynamically
  // resolve "whoever holds that specific permission."
  // ═══════════════════════════════════════════════════════════

  /// Can `member` submit a generic feature access request at all?
  /// Any office-tier member — Platoon Office, Company Office, or
  /// Brigade Office. Master Access doesn't need this (they already
  /// have everything), so they're excluded rather than redundantly
  /// allowed.
  static bool canRequestFeatureAccess(Member member) {
    if (hasAdminOrMasterAccess(member)) return false;
    return member.unitType == UnitType.platoonOffice ||
        member.unitType == UnitType.companyOffice ||
        member.unitType == UnitType.brigadeOffice;
  }

  /// Can `member` approve/deny generic feature access requests?
  /// Master Access/Admin only — these requests are deliberately
  /// always routed to the top tier, not resolved per-permission.
  static bool canApproveFeatureAccess(Member member) {
    return hasAdminOrMasterAccess(member);
  }

  // Two separate questions, deliberately kept apart:
  //   1. canSeeInMemberList — does this member show up at all when
  //      `viewer` searches/browses the Members list? (Brigade-wide
  //      for everyone — see method below.)
  //   2. canViewFullDetail — once visible, can `viewer` open the
  //      full Info/Analytics/ID Card tabs, or only contact-info-level
  //      fields (name, rank, phone, email, unit/company)?
  //
  // NOTE: canViewMember (above) is left untouched — it's still used
  // by duty/report/other modules for their own scope checks. These
  // new methods are specific to the Members screen.
  // ═══════════════════════════════════════════════════════════

  /// Can `viewer` see `target` show up in the Members list at all?
  /// Can `viewer` see `target` show up in the Members list at all?
  /// Brigade-wide for EVERYONE — the list itself shows the entire
  /// roster to every member, regardless of rank or company. What's
  /// restricted is the DETAIL shown once you tap in (see
  /// canViewFullDetail below) — not whether the member appears here.
  static bool canSeeInMemberList(Member viewer, Member target) {
    return true;
  }

  /// Can `viewer` see `target`'s FULL detail — Info tab, Analytics tab,
  /// AND ID Card tab all derive from this single rule. If false, the
  /// caller should hide those tabs entirely (not show a locked
  /// placeholder) and fall back to contact-info-only fields (name,
  /// rank, phone, email, unit/company) wherever target is shown.
  ///
  /// Rules, in order:
  ///   1. Own profile — always full detail.
  ///   2. Master Access/Admin viewing a target who is NOT themselves
  ///      Master Access/Admin — always full detail, regardless of
  ///      company (Master Access tier sees everyone "below" it fully).
  ///   3. Master Access/Admin viewing ANOTHER Master Access/Admin
  ///      target — falls through to rule 4 (rank order still applies
  ///      between Master Access holders, e.g. Deputy viewing Brigade
  ///      Commander needs to outrank, which they don't, so no detail).
  ///   4. Everyone else: same company AND viewer outranks target.
  ///      Different company, or same company without outranking →
  ///      contact-info-only.
  static bool canViewFullDetail(Member viewer, Member target) {
    if (viewer.id == target.id) return true;

    final viewerIsMaster = hasAdminOrMasterAccess(viewer);
    final targetIsMaster = hasAdminOrMasterAccess(target);

    // Master Access/Admin viewing a non-Master target — always full
    // detail, regardless of company.
    if (viewerIsMaster && !targetIsMaster) return true;

    // Both are Master Access/Admin (e.g. Brigade Commander viewing
    // Deputy, or Deputy viewing Brigade Commander) — rank order decides
    // between them directly. This does NOT go through the company-match
    // check below, since Brigade Office members share no companyNo.
    if (viewerIsMaster && targetIsMaster) {
      return RankHelper.isHigherThan(viewer.rank, target.rank);
    }

    // Viewer is not Master Access. A non-Master viewer can never see a
    // Master Access target's detail (Brigade Office is always
    // protected from below).
    if (targetIsMaster) return false;

    // Standard same-company + outranks rule for everyone else. Note:
    // this already gives Company Sergeant Major company-wide detail
    // visibility over anyone they outrank (no platoon restriction
    // here — that restriction only applies to getUnitScope, used for
    // duty/report scope elsewhere, not to Members-screen detail
    // visibility). Viewing a superior (Commander/Deputy) requires an
    // approved AccessGrantRequest instead — see canViewGrantedSection.
    if (viewer.companyNo != target.companyNo) return false;
    return RankHelper.isHigherThan(viewer.rank, target.rank);
  }

  /// Can `viewer` see `target`'s ID card fullscreen landscape view?
  /// STRICTLY self-only — no exception for any rank, including Master
  /// Access/Admin. Fullscreen is for showing your OWN card to someone
  /// in person; it is never used to display someone else's card.
  static bool canViewIdCardFullscreen(Member viewer, Member target) {
    return viewer.id == target.id;
  }

  // ═══════════════════════════════════════════════════════════
  // MODULE 4 ADDITIONS — Add Member permissions
  // ═══════════════════════════════════════════════════════════

  /// Can `member` add a new member directly (no approval needed)?
  /// Master Access, Admin, Company Commander, Deputy Company Commander.
  static bool canAddMemberDirectly(Member member) {
    if (hasAdminOrMasterAccess(member)) return true;
    if (member.rank == MemberRank.companyCommander) return true;
    if (member.rank == MemberRank.deputyCompanyCommander) return true;
    return false;
  }

  /// Can `member` propose a new member (needs Company Commander approval)?
  /// Platoon Leader and Section Leader only.
  static bool canProposeNewMember(Member member) {
    if (member.rank == MemberRank.platoonLeader) return true;
    if (member.rank == MemberRank.sectionLeader) return true;
    return false;
  }

  /// Can `member` add OR propose a new member at all (used to show the
  /// Add Member button — actual flow differs based on which is true).
  static bool canAddOrProposeMember(Member member) {
    return canAddMemberDirectly(member) || canProposeNewMember(member);
  }

  /// Can `approver` approve a pending member proposal submitted within
  /// their company? Only Company Commander / Deputy Company Commander
  /// of the SAME company as the proposer, or Master Access/Admin.
  static bool canApproveNewMemberProposal(Member approver, Member proposer) {
    if (hasAdminOrMasterAccess(approver)) return true;
    final isCompanyLead = approver.rank == MemberRank.companyCommander ||
        approver.rank == MemberRank.deputyCompanyCommander;
    if (!isCompanyLead) return false;
    return approver.companyNo == proposer.companyNo;
  }


  /// Admin role has same power as Master Access for most things,
  /// EXCEPT acting on Deputy Brigade Commander+ requires approval
  /// (handled via adminApprovalTierFor at the workflow layer).
  static bool hasAdminOrMasterAccess(Member member) {
    return member.isAdminRole || hasMasterAccess(member);
  }

  /// Can `actor` toggle `target`'s availability directly (no approval)?
  /// Available/Not Available is ALWAYS a direct change — no approval
  /// step for anyone, at any rank, changing their own OR someone
  /// else's short-term availability. The only requirement is that the
  /// actor can see/manage the target at all (existing canViewMember
  /// scope still applies — this doesn't bypass who can act on whom,
  /// it just removes the approval gate for availability specifically).
  /// A notification is sent up the target's full chain of command as
  /// an FYI — see MockNotifications.notifyChainOfCommandOfAvailabilityChange.
  static bool canToggleAvailabilityDirectly(Member actor, Member target) {
    if (actor.id == target.id) return true;
    if (hasAdminOrMasterAccess(actor)) return true;
    return canViewMember(actor, target);
  }

  /// Active/Inactive status — direct change, no approval. ONLY Master
  /// Access or Admin role. Nobody (including self) can change their
  /// own active/inactive this way. This is the path for disciplinary
  /// suspension/dismissal (see Module 16) — for long leave/overseas,
  /// use canRequestInactiveLeaveToggle below instead.
  static bool canChangeActiveStatus(Member actor, Member target) {
    return hasAdminOrMasterAccess(actor);
  }

  /// Long leave / overseas Active ↔ Inactive toggle — SAME approval
  /// pattern as Available/Not Available:
  ///   - Master Access/Admin: direct, no approval.
  ///   - Self: can request own long-leave status, needs approval from
  ///     own higher rank.
  ///   - Higher rank (same unit scope): can request on someone else's
  ///     behalf, needs approval from THEIR own higher rank.
  /// This is distinct from canChangeActiveStatus, which is the
  /// disciplinary/direct-only path.
  static bool canRequestInactiveLeaveToggle(Member actor, Member target) {
    if (hasAdminOrMasterAccess(actor)) return true; // direct, not request

    // Self-request: any member can request their own long-leave status
    if (actor.id == target.id) return true;

    // Higher rank requesting for someone below them, same unit scope
    final actorIsHigher = RankHelper.isHigherThan(actor.rank, target.rank);
    if (!actorIsHigher) return false;

    if (actor.unitType == UnitType.brigadeOffice) return true;
    return actor.companyNo == target.companyNo;
  }

  /// Is `member` eligible to be assigned to a duty, meeting, or class?
  /// Used by assignment pickers in later modules (Duties, Meetings,
  /// Classes) to filter out members who are inactive for long leave.
  /// NOT the same as `isAvailable` (short-term, day-to-day scheduling)
  /// — this specifically excludes the long-leave/overseas case.
  static bool isEligibleForAssignment(Member member) {
    if (member.status == MemberStatus.inactive &&
        member.inactiveReason != null) {
      return false;
    }
    if (member.status == MemberStatus.suspended) return false;
    if (member.status == MemberStatus.dismissed) return false;
    return true;
  }

  /// Rank/role changes — ONLY Master Access or Admin role.
  /// Self cannot change own rank/role even if Master Access
  /// (must go through formal order process — UI enforces this).
  static bool canChangeRankOrRole(Member actor, Member target) {
    if (actor.id == target.id) return false; // never self
    return hasAdminOrMasterAccess(actor);
  }

  /// Approval tier needed for Admin (non-Master-Access) to act on `target`.
  /// Returns null if no approval needed (target is below Deputy rank).
  /// Returns 'single' if needs 1 of Brigade Commander/Deputy.
  /// Returns 'double' if needs 2 of Chairperson/Commander/Deputy.
  static String? adminApprovalTierFor(Member target) {
    if (target.isChairperson || target.rank == MemberRank.brigadeCommander) {
      return 'double';
    }
    if (target.rank == MemberRank.deputyBrigadeCommander ||
        target.isBrigadeOfficeChief) {
      return 'single';
    }
    return null; // Platoon Leader and below — Admin can act directly
  }

  // ═══════════════════════════════════════════════════════════
  // MODULE 9 ADDITIONS — Classes & Training
  // Mirrors the Meetings permission pattern (Module 8) exactly,
  // per the locked decision to use the same creator tier.
  // ═══════════════════════════════════════════════════════════

  /// Can `member` create a class at all (regardless of scope)?
  /// Master Access/Admin — any unit. Deputy Company Commander,
  /// Company Commander, Deputy Brigade Commander, Brigade Commander
  /// — for their own unit only (scope checked via
  /// canCreateClassForUnit).
  static bool canCreateClass(Member member) {
    if (hasAdminOrMasterAccess(member)) return true;
    const eligibleRanks = {
      MemberRank.deputyCompanyCommander,
      MemberRank.companyCommander,
      MemberRank.deputyBrigadeCommander,
      MemberRank.brigadeCommander,
    };
    return eligibleRanks.contains(member.rank);
  }

  /// Can `member` create a class specifically for `targetCompanyNo`
  /// (null = brigade-wide)? Same scoping rule as
  /// canCreateMeetingForUnit.
  static bool canCreateClassForUnit(Member member, int? targetCompanyNo) {
    if (hasAdminOrMasterAccess(member)) return true;
    if (!canCreateClass(member)) return false;
    if (member.unitType == UnitType.brigadeOffice) return true;
    return member.companyNo == targetCompanyNo;
  }

  /// Can `member` edit/cancel a class, manage its committee/budget,
  /// or directly add/remove enrolled members? Same authority as
  /// creating it — EXCEPT once the class is frozen, which happens
  /// when EITHER of these becomes true (whichever happens first):
  ///   - status is ongoing/completed/archived, OR
  ///   - today's date is on or after the class's startDate
  /// There is no request/unlock path for the class data itself once
  /// frozen — only the Closure Report has one (see
  /// canEditClosureReportSection below).
  static bool canManageClass(
    Member member,
    int? classCompanyNo,
    ClassStatus classStatus,
    DateTime classStartDate,
  ) {
    final statusFrozen = classStatus == ClassStatus.ongoing ||
        classStatus == ClassStatus.completed ||
        classStatus == ClassStatus.archived;
    final dateFrozen = !DateTime.now().isBefore(
      DateTime(classStartDate.year, classStartDate.month, classStartDate.day),
    );
    if (statusFrozen || dateFrozen) return false;
    return canCreateClassForUnit(member, classCompanyNo);
  }

  /// Can `member` edit `section` of a Closure Report right now?
  /// Always true before the report locks (no deadline set yet, or
  /// deadline hasn't passed). After locking, only true if `member`
  /// is Master Access AND `section` is in `grantedSections` from an
  /// approved ClosureReportEditRequest.
  static bool canEditClosureReportSection(
    Member member,
    ClosureReportSection section, {
    required bool reportIsLocked,
    required List<ClosureReportSection> grantedSections,
  }) {
    if (!reportIsLocked) return true;
    if (!hasAdminOrMasterAccess(member)) return false;
    return grantedSections.contains(section);
  }

  /// Can `member` set/change a Closure Report's submission deadline?
  /// Master Access only.
  static bool canSetClosureReportDeadline(Member member) {
    return hasAdminOrMasterAccess(member);
  }

  /// Can `member` submit a ClassNominationList for `companyNo`? Same
  /// tier as creating a class for that unit — Company Commander/
  /// Deputy for their own company, Master Access for any.
  static bool canSubmitNominationList(Member member, int companyNo) {
    return canCreateClassForUnit(member, companyNo);
  }

  /// Can `member` set/change a nomination list's submission
  /// deadline? Master Access only — same tier as the Closure Report
  /// deadline, per the locked rule.
  static bool canSetNominationDeadline(Member member) {
    return hasAdminOrMasterAccess(member);
  }

  /// Can `member` approve/deny a ClosureReportEditRequest? Master
  /// Access only — this is the one exception to "finished classes
  /// can't be touched," and it's deliberately gated to the top tier
  /// regardless of which company the class belongs to.
  static bool canApproveClosureReportEditRequest(Member member) {
    return hasAdminOrMasterAccess(member);
  }

  /// Can `member` approve/deny an EnrollmentRequest for this class?
  /// Same authority as managing the class — the instructor/committee
  /// chain isn't separately modeled yet, so this reuses the class
  /// management tier. Freezes along with the class once finished,
  /// same as everything else covered by canManageClass.
  static bool canApproveEnrollment(
    Member member,
    int? classCompanyNo,
    ClassStatus classStatus,
    DateTime classStartDate,
  ) {
    return canManageClass(member, classCompanyNo, classStatus, classStartDate);
  }

  /// Can `member` submit feedback for a class? Only members who were
  /// actually enrolled (and presumably attended) — checked by the
  /// caller passing in whether this member's id is in
  /// TrainingClass.enrolledMemberIds, since that's data-dependent
  /// rather than a pure rank/role rule.
  static bool canSubmitFeedback(Member member, List<String> enrolledMemberIds) {
    return enrolledMemberIds.contains(member.id);
  }

  /// Can `member` prepare a Class Closure Report? Same rank tier as
  /// managing the class, but DELIBERATELY does not freeze once the
  /// class is completed/archived — preparing the closure report is
  /// explicitly a post-completion activity, unlike everything else
  /// canManageClass covers.
  static bool canPrepareClosureReport(Member member, int? classCompanyNo) {
    return canCreateClassForUnit(member, classCompanyNo);
  }

  /// Can `member` prepare a Post-Training Report (HQ version)? Same
  /// reasoning as canPrepareClosureReport — must not freeze on
  /// class completion, since this report is prepared afterward.
  static bool canPreparePostTrainingReport(Member member, int? classCompanyNo) {
    return canCreateClassForUnit(member, classCompanyNo);
  }

  /// Can `member` approve a Post-Training Report (the HQ sign-off)?
  /// Same "leadership sign-off" tier used for Meeting Minutes
  /// approval — Brigade Office Chief, Deputy Brigade Commander,
  /// Brigade Commander, or Master Access/Admin.
  static bool canApprovePostTrainingReport(Member member) {
    if (hasAdminOrMasterAccess(member)) return true;
    return member.isBrigadeOfficeChief ||
        member.rank == MemberRank.deputyBrigadeCommander ||
        member.rank == MemberRank.brigadeCommander;
  }

  // ═══════════════════════════════════════════════════════════
  // EMERGENCY DUTY ADDITIONS
  // For unexpected accidents/disasters — deliberately open, since
  // requiring rank-gated creation would delay response to a real
  // emergency. ANY active member can create one or self-check-in;
  // only the final report submission is gated to leadership.
  // ═══════════════════════════════════════════════════════════

  /// Can `member` create an Emergency Duty? Any active member —
  /// whoever arrives first at an unexpected accident should be able
  /// to log it immediately, with no rank gate slowing that down.
  static bool canCreateEmergencyDuty(Member member) {
    return member.status == MemberStatus.active;
  }

  /// Can `member` self check-in to `duty`? True for ANY duty type
  /// (not just emergency) — per the locked rule that real-time
  /// check-in applies to all duties. Real-time location verification
  /// is held for Module 16/19; this is presence-intent only for now.
  static bool canCheckIn(Member member, Duty duty) {
    return member.status == MemberStatus.active;
  }

  /// Can `member` submit/approve the final report for an Emergency
  /// Duty? Same "leadership sign-off" tier used throughout the app —
  /// Brigade Office Chief, Deputy Brigade Commander, Brigade
  /// Commander, or Master Access/Admin. Deliberately NOT the duty's
  /// own Commander/Officer, since the locked requirement specifically
  /// calls for "higher up" approval beyond whoever responded.
  static bool canApproveEmergencyDutyReport(Member member) {
    if (hasAdminOrMasterAccess(member)) return true;
    return member.isBrigadeOfficeChief ||
        member.rank == MemberRank.deputyBrigadeCommander ||
        member.rank == MemberRank.brigadeCommander;
  }

  /// Can `member` escalate a completed disaster-level Emergency Duty
  /// to a Large Scale operation? The duty's own Commander/Officer
  /// (whoever led the response), or Master Access — this is a
  /// tactical decision made by whoever was actually there, not
  /// routed through the same leadership-approval tier as the report.
  static bool canEscalateToLargeScale(Member member, Duty duty) {
    if (hasAdminOrMasterAccess(member)) return true;
    return canMakeDecisionInDuty(member, duty);
  }

  // ═══════════════════════════════════════════════════════════
  // INVESTIGATION MEETING ADDITIONS
  // ═══════════════════════════════════════════════════════════

  /// Given the resolved Member objects for an investigation's
  /// committee, returns whichever one is highest-ranking — treated
  /// as the Committee Chairman, per the locked decision (computed
  /// dynamically, no explicit chairman field needed). Returns null
  /// if the committee is empty.
  ///
  /// Takes resolved Member objects rather than IDs since
  /// PermissionService doesn't depend on MockMembers (mock_data.dart
  /// already depends on this file — a reverse import would be
  /// circular) — the caller looks up the members first.
  static Member? committeeChairman(List<Member> committeeMembers) {
    if (committeeMembers.isEmpty) return null;
    final sorted = List<Member>.from(committeeMembers)
      ..sort((a, b) => RankHelper.rankOrder(a.rank).compareTo(RankHelper.rankOrder(b.rank)));
    return sorted.first;
  }

  /// Is `member` the Committee Chairman of this investigation's
  /// committee (highest-ranking member)?
  static bool isCommitteeChairman(Member member, List<Member> committeeMembers) {
    final chairman = committeeChairman(committeeMembers);
    return chairman != null && chairman.id == member.id;
  }

  /// Can `member` request to invite a higher-rank officer to an
  /// Investigation meeting? Only the Committee Chairman — anyone
  /// else on the committee isn't authorized to expand who's invited.
  static bool canRequestOfficerInvite(Member member, List<Member> committeeMembers) {
    return isCommitteeChairman(member, committeeMembers);
  }

  /// Can `member` add an officer to the meeting DIRECTLY, with no
  /// approval needed? Master Access only.
  static bool canAddOfficerDirectly(Member member) {
    return hasAdminOrMasterAccess(member);
  }

  /// Can `member` approve/deny a pending OfficerInviteRequest? Master
  /// Access only — same tier as direct-add, since this is the
  /// approval step for the Chairman's request.
  static bool canApproveOfficerInvite(Member member) {
    return hasAdminOrMasterAccess(member);
  }
}
